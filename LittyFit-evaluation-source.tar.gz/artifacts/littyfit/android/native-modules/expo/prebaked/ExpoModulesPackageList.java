package com.littyverse.littyfit;

import java.util.Arrays;
import java.util.List;
import expo.modules.core.interfaces.Package;
import expo.modules.kotlin.modules.Module;
import expo.modules.kotlin.ModulesProvider;

public class ExpoModulesPackageList implements ModulesProvider {
  private static class LazyHolder {
    static final List<Package> packagesList = Arrays.<Package>asList(
      new expo.modules.adapters.react.ReactAdapterPackage(),
      new expo.modules.constants.ConstantsPackage(),
      new expo.modules.core.BasePackage(),
      new expo.modules.filesystem.legacy.FileSystemPackage(),
      new expo.modules.imageloader.ImageLoaderPackage(),
      new expo.modules.keepawake.KeepAwakePackage(),
      new expo.modules.kotlin.edgeToEdge.EdgeToEdgePackage(),
      new expo.modules.linking.ExpoLinkingPackage(),
      new expo.modules.systemui.SystemUIPackage()
    );

    static final List<Class<? extends Module>> modulesList = Arrays.<Class<? extends Module>>asList(
            expo.modules.fetch.ExpoFetchModule.class,
      expo.modules.asset.AssetModule.class,
      expo.modules.blur.BlurModule.class,
      expo.modules.constants.ConstantsModule.class,
      expo.modules.filesystem.FileSystemModule.class,
      expo.modules.filesystem.legacy.FileSystemLegacyModule.class,
      expo.modules.font.FontLoaderModule.class,
      expo.modules.font.FontUtilsModule.class,
      expo.modules.haptics.HapticsModule.class,
      expo.modules.image.ExpoImageModule.class,
      expo.modules.imagepicker.ImagePickerModule.class,
      expo.modules.keepawake.KeepAwakeModule.class,
      expo.modules.lineargradient.LinearGradientModule.class,
      expo.modules.linking.ExpoLinkingModule.class,
      expo.modules.location.LocationModule.class,
      expo.modules.securestore.SecureStoreModule.class,
      expo.modules.splashscreen.SplashScreenModule.class,
      expo.modules.systemui.SystemUIModule.class,
      expo.modules.webbrowser.WebBrowserModule.class
    );
  }

  public static List<Package> getPackageList() {
    return LazyHolder.packagesList;
  }

  @Override
  public List<Class<? extends Module>> getModulesList() {
    return LazyHolder.modulesList;
  }
}
