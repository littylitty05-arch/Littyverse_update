import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from "react";
import * as SecureStore from "expo-secure-store";
import { apiFetch } from "../lib/api";

export interface AuthUser {
  id: string | number;
  username: string;
  email: string;
  firstName?: string;
  profileImageUrl?: string;
  isDemo?: boolean;
}

const DEMO_USER: AuthUser = {
  id: "demo",
  username: "LittyDemo",
  email: "demo@littyverse.com",
  firstName: "Demo",
  isDemo: true,
};

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  login: (identifier: string, password: string) => Promise<void>;
  demoLogin: () => void;
  logout: () => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  login: async () => {},
  demoLogin: () => {},
  logout: async () => {},
  isLoading: true,
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const stored = await SecureStore.getItemAsync("ltk_token");
        if (stored) {
          const res = await apiFetch("/api/auth/mobile-me");
          if (res.ok) {
            const u = await res.json();
            setUser(u);
            setToken(stored);
          } else {
            await SecureStore.deleteItemAsync("ltk_token");
          }
        }
      } catch {}
      setIsLoading(false);
    })();
  }, []);

  const login = async (identifier: string, password: string) => {
    const res = await apiFetch("/api/auth/mobile-login", {
      method: "POST",
      body: JSON.stringify({ identifier, password }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.message ?? "Login failed");
    }
    const { token: t, user: u } = await res.json();
    await SecureStore.setItemAsync("ltk_token", t);
    setToken(t);
    setUser(u);
  };

  const demoLogin = () => {
    setUser(DEMO_USER);
    setToken(null);
  };

  const logout = async () => {
    await SecureStore.deleteItemAsync("ltk_token").catch(() => {});
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, demoLogin, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
