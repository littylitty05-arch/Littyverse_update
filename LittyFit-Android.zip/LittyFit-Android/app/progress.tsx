import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { apiFetch } from "@/lib/api";

const MOOD_LABELS = ["", "Bad", "Poor", "OK", "Good", "Great"];
const MOOD_COLORS = ["", "#ef4444", "#f59e0b", "#a78bfa", "#10b981", "#22c55e"];

export default function ProgressScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [weight, setWeight] = useState("");
  const [energy, setEnergy] = useState(0);
  const [mood, setMood] = useState(0);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const { data: history, refetch } = useQuery({
    queryKey: ["progress-history"],
    queryFn: async () => {
      const res = await apiFetch("/api/littyfit/progress");
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user,
  });

  const saveProgress = async () => {
    setSaving(true);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await apiFetch("/api/littyfit/progress", {
        method: "POST",
        body: JSON.stringify({
          weightLbs: weight ? parseFloat(weight) : undefined,
          energyLevel: energy || undefined,
          mood: mood || undefined,
          notes: notes || undefined,
        }),
      });
      setWeight("");
      setEnergy(0);
      setMood(0);
      setNotes("");
      refetch();
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {}
    setSaving(false);
  };

  const recentHistory = (history ?? []).slice(0, 30);
  const weights = recentHistory.filter((e: any) => e.weightLbs).map((e: any) => e.weightLbs);
  const maxW = weights.length ? Math.max(...weights) : 200;
  const minW = weights.length ? Math.min(...weights) : 150;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPad + 20 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPad + 16 }]}>
        <Pressable
          style={[styles.backBtn, { backgroundColor: colors.card }]}
          onPress={() => router.back()}
        >
          <AppIcon name="chevron-back" size={20} color={colors.textPrimary} />
        </Pressable>
        <Text style={[styles.title, { color: colors.purpleLight }]}>Progress</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Track your journey
        </Text>
      </View>

      <View style={styles.content}>
        {/* Weight Chart */}
        {weights.length > 1 && (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Weight Trend</Text>
            <View style={styles.chart}>
              {recentHistory
                .filter((e: any) => e.weightLbs)
                .slice(-10)
                .map((entry: any, i: number, arr: any[]) => {
                  const h = maxW === minW ? 50 : ((entry.weightLbs - minW) / (maxW - minW)) * 80 + 10;
                  return (
                    <View key={i} style={styles.barCol}>
                      <View style={[styles.weightBar, { height: h, backgroundColor: colors.purple }]} />
                      <Text style={[styles.barLabel, { color: colors.textMuted }]}>
                        {entry.weightLbs}
                      </Text>
                    </View>
                  );
                })}
            </View>
          </View>
        )}

        {/* Energy & Mood History */}
        {recentHistory.length > 0 && (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Energy & Mood</Text>
            <View style={styles.dotsContainer}>
              {recentHistory.slice(0, 14).map((entry: any, i: number) => (
                <View key={i} style={styles.dotEntry}>
                  <View
                    style={[styles.energyDot, { backgroundColor: MOOD_COLORS[entry.energyLevel ?? 0] || colors.muted }]}
                  />
                  <View
                    style={[styles.moodDot, { backgroundColor: MOOD_COLORS[entry.mood ?? 0] || colors.muted }]}
                  />
                </View>
              ))}
            </View>
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: colors.purpleLight }]} />
                <Text style={[styles.legendText, { color: colors.textMuted }]}>Energy</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: colors.amber }]} />
                <Text style={[styles.legendText, { color: colors.textMuted }]}>Mood</Text>
              </View>
            </View>
          </View>
        )}

        {/* Log Today */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Log Today</Text>

          {/* Weight */}
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Weight (lbs)</Text>
            <TextInput
              style={[styles.textInput, { backgroundColor: colors.secondary, borderColor: colors.border, color: colors.textPrimary }]}
              value={weight}
              onChangeText={setWeight}
              placeholder="e.g. 175"
              placeholderTextColor={colors.textMuted}
              keyboardType="decimal-pad"
            />
          </View>

          {/* Energy */}
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Energy Level</Text>
            <View style={styles.ratingRow}>
              {[1, 2, 3, 4, 5].map((v) => (
                <Pressable
                  key={v}
                  style={[
                    styles.ratingBtn,
                    {
                      backgroundColor: energy === v ? colors.purpleLight : colors.secondary,
                      borderColor: energy === v ? colors.purpleLight : colors.border,
                    },
                  ]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setEnergy(v);
                  }}
                >
                  <Text style={[styles.ratingLabel, { color: energy === v ? "white" : colors.textSecondary }]}>
                    {v}
                  </Text>
                  <Text style={[styles.ratingMoodLabel, { color: energy === v ? "white" : colors.textMuted }]}>
                    {MOOD_LABELS[v]}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Mood */}
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Mood</Text>
            <View style={styles.ratingRow}>
              {[1, 2, 3, 4, 5].map((v) => (
                <Pressable
                  key={v}
                  style={[
                    styles.ratingBtn,
                    {
                      backgroundColor: mood === v ? colors.amber : colors.secondary,
                      borderColor: mood === v ? colors.amber : colors.border,
                    },
                  ]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setMood(v);
                  }}
                >
                  <Text style={[styles.ratingLabel, { color: mood === v ? "white" : colors.textSecondary }]}>
                    {v}
                  </Text>
                  <Text style={[styles.ratingMoodLabel, { color: mood === v ? "white" : colors.textMuted }]}>
                    {MOOD_LABELS[v]}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Notes */}
          <View style={styles.field}>
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Notes (optional)</Text>
            <TextInput
              style={[styles.notesInput, { backgroundColor: colors.secondary, borderColor: colors.border, color: colors.textPrimary }]}
              value={notes}
              onChangeText={setNotes}
              placeholder="How did today feel?"
              placeholderTextColor={colors.textMuted}
              multiline
              numberOfLines={3}
            />
          </View>

          <Pressable
            style={[styles.saveBtn, { backgroundColor: colors.purple }]}
            onPress={saveProgress}
            disabled={saving}
          >
            {saving ? <ActivityIndicator color="white" /> : <Text style={styles.saveBtnText}>Save Progress</Text>}
          </Pressable>
        </View>

        {/* History List */}
        {recentHistory.length > 0 && (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Recent Logs</Text>
            {recentHistory.slice(0, 7).map((entry: any, i: number) => (
              <View
                key={i}
                style={[styles.historyRow, { borderTopWidth: i > 0 ? 1 : 0, borderTopColor: colors.border }]}
              >
                <Text style={[styles.historyDate, { color: colors.textMuted }]}>
                  {new Date(entry.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                </Text>
                <View style={styles.historyMeta}>
                  {entry.weightLbs && (
                    <Text style={[styles.historyWeight, { color: colors.textPrimary }]}>{entry.weightLbs} lbs</Text>
                  )}
                  {entry.energyLevel && (
                    <View style={[styles.dot, { backgroundColor: MOOD_COLORS[entry.energyLevel] }]} />
                  )}
                  {entry.mood && (
                    <View style={[styles.dot, { backgroundColor: MOOD_COLORS[entry.mood] }]} />
                  )}
                </View>
                {entry.notes && (
                  <Text style={[styles.historyNotes, { color: colors.textSecondary }]} numberOfLines={1}>
                    {entry.notes}
                  </Text>
                )}
              </View>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  title: { fontSize: 28, fontWeight: "900" },
  subtitle: { fontSize: 14, marginTop: 4 },
  content: { paddingHorizontal: 20, gap: 16 },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 16 },
  cardTitle: { fontSize: 17, fontWeight: "700" },
  chart: { flexDirection: "row", alignItems: "flex-end", gap: 6, height: 100 },
  barCol: { flex: 1, alignItems: "center", gap: 4 },
  weightBar: { width: "100%", borderRadius: 4, minHeight: 8 },
  barLabel: { fontSize: 9 },
  dotsContainer: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  dotEntry: { alignItems: "center", gap: 4 },
  energyDot: { width: 12, height: 12, borderRadius: 6 },
  moodDot: { width: 12, height: 12, borderRadius: 6 },
  legendRow: { flexDirection: "row", gap: 16 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 12 },
  field: { gap: 8 },
  fieldLabel: { fontSize: 12, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.5 },
  textInput: { borderRadius: 12, borderWidth: 1, padding: 12, fontSize: 16 },
  notesInput: { borderRadius: 12, borderWidth: 1, padding: 12, fontSize: 14, minHeight: 80, textAlignVertical: "top" },
  ratingRow: { flexDirection: "row", gap: 8 },
  ratingBtn: { flex: 1, borderRadius: 10, borderWidth: 1, padding: 8, alignItems: "center", gap: 2 },
  ratingLabel: { fontSize: 16, fontWeight: "700" },
  ratingMoodLabel: { fontSize: 9, fontWeight: "600" },
  saveBtn: { padding: 14, borderRadius: 14, alignItems: "center" },
  saveBtnText: { color: "white", fontWeight: "700", fontSize: 16 },
  historyRow: { paddingVertical: 10, gap: 4 },
  historyDate: { fontSize: 12, fontWeight: "600" },
  historyMeta: { flexDirection: "row", alignItems: "center", gap: 8 },
  historyWeight: { fontSize: 15, fontWeight: "700" },
  dot: { width: 10, height: 10, borderRadius: 5 },
  historyNotes: { fontSize: 13 },
});
