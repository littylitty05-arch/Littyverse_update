import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Platform,
  Animated,
  SafeAreaView,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { apiFetch } from "@/lib/api";
import { WORKOUT_PROGRAMS, WorkoutDay, Exercise } from "@/data/littyfit";
import LTKRewardModal from "@/components/LTKRewardModal";

export default function WorkoutSession() {
  const colors = useColors();
  const params = useLocalSearchParams<{ programId: string; day: string; exercisesJson?: string; isQuick?: string }>();
  const qc = useQueryClient();

  const isQuick = params.isQuick === "true";
  const program = isQuick ? null : WORKOUT_PROGRAMS.find((p) => p.id === params.programId);
  const dayIndex = parseInt(params.day ?? "1") - 1;
  const day: WorkoutDay | undefined = program?.days[Math.min(dayIndex, (program?.days.length ?? 1) - 1)];
  const exercises: Exercise[] = isQuick
    ? (JSON.parse(params.exercisesJson ?? "[]") as Exercise[])
    : (day?.exercises ?? []);

  const [currentExerciseIdx, setCurrentExerciseIdx] = useState(0);
  const [phase, setPhase] = useState<"exercise" | "rest" | "done">("exercise");
  const [timeLeft, setTimeLeft] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [showReward, setShowReward] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(50);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const elapsedRef = useRef(0);

  const currentExercise = exercises[currentExerciseIdx];
  const exerciseDuration = currentExercise?.duration ?? 40;

  useEffect(() => {
    setTimeLeft(exerciseDuration);
    const prog = (currentExerciseIdx / exercises.length);
    Animated.timing(progressAnim, { toValue: prog, duration: 400, useNativeDriver: false }).start();
  }, [currentExerciseIdx]);

  useEffect(() => {
    const interval = setInterval(() => {
      elapsedRef.current++;
      setElapsed(elapsedRef.current);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (phase === "done") return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          if (phase === "exercise") {
            if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setPhase("rest");
            setTimeLeft(15);
          } else {
            advanceExercise();
          }
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [phase, currentExerciseIdx]);

  const advanceExercise = useCallback(() => {
    const next = currentExerciseIdx + 1;
    if (next >= exercises.length) {
      setPhase("done");
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      completeWorkout(true);
    } else {
      setCurrentExerciseIdx(next);
      setPhase("exercise");
      setTimeLeft(exercises[next]?.duration ?? 40);
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, [currentExerciseIdx, exercises.length]);

  const completeWorkout = async (verified: boolean) => {
    const ltk = verified ? 50 : 20;
    setRewardAmount(ltk);
    try {
      await apiFetch("/api/littyfit/workouts/complete", {
        method: "POST",
        body: JSON.stringify({
          programId: params.programId,
          dayIndex,
          durationSeconds: elapsedRef.current,
          verified,
        }),
      });
      qc.invalidateQueries({ queryKey: ["littyfit-stats"] });
      qc.invalidateQueries({ queryKey: ["ltk-balance"] });
      qc.invalidateQueries({ queryKey: ["ltk-history"] });
    } catch {}
    setShowReward(true);
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  if (!isQuick && (!program || !day)) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <Text style={[styles.errorText, { color: colors.textSecondary }]}>Workout not found</Text>
        <Pressable onPress={() => router.back()} style={[styles.backBtnSm, { backgroundColor: colors.purple }]}>
          <Text style={{ color: "white", fontWeight: "700" }}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const sessionTitle = isQuick ? "Quick Workout" : (program?.title ?? "Workout");
  const sessionSub = isQuick ? `${exercises.length} exercises · No excuses` : (day?.name ?? "");

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={styles.topBar}>
        <Pressable onPress={() => router.back()} style={[styles.closeBtn, { backgroundColor: colors.card }]}>
          <AppIcon name="close" size={22} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.topInfo}>
          <Text style={[styles.programLabel, { color: colors.textMuted }]}>{sessionTitle}</Text>
          <Text style={[styles.dayLabel, { color: colors.textSecondary }]}>{sessionSub}</Text>
        </View>
        <Text style={[styles.elapsedTime, { color: colors.textMuted }]}>{formatTime(elapsed)}</Text>
      </View>

      {/* Progress Bar */}
      <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
        <Animated.View style={[styles.progressFill, { width: progressWidth, backgroundColor: colors.purple }]} />
      </View>

      <View style={styles.content}>
        {phase !== "done" ? (
          <>
            {/* Exercise Counter */}
            <Text style={[styles.exerciseCounter, { color: colors.textMuted }]}>
              {currentExerciseIdx + 1} / {exercises.length}
            </Text>

            {/* Phase Label */}
            <View style={[styles.phaseBadge, { backgroundColor: phase === "rest" ? "rgba(16,185,129,0.15)" : "rgba(124,58,237,0.15)" }]}>
              <Text style={[styles.phaseText, { color: phase === "rest" ? colors.green : colors.purpleLight }]}>
                {phase === "rest" ? "REST" : "EXERCISE"}
              </Text>
            </View>

            {/* Exercise Name */}
            <Text style={[styles.exerciseName, { color: colors.textPrimary }]}>
              {phase === "rest" ? "Rest" : currentExercise?.name ?? ""}
            </Text>

            {/* Sets/Reps */}
            {phase === "exercise" && (
              <Text style={[styles.setsReps, { color: colors.purpleLight }]}>
                {currentExercise?.sets} sets × {currentExercise?.reps}
              </Text>
            )}

            {/* Timer */}
            <View style={[styles.timerCircle, { borderColor: phase === "rest" ? colors.green : colors.purple, backgroundColor: colors.card }]}>
              <Text style={[styles.timerText, { color: phase === "rest" ? colors.green : colors.textPrimary }]}>
                {timeLeft}
              </Text>
              <Text style={[styles.timerSub, { color: colors.textMuted }]}>sec</Text>
            </View>

            {/* Instructions */}
            {phase === "exercise" && (
              <Text style={[styles.instructions, { color: colors.textSecondary }]}>
                {currentExercise?.instructions ?? ""}
              </Text>
            )}

            {/* Controls */}
            <View style={styles.controls}>
              <Pressable
                style={[styles.skipBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  if (phase === "exercise") {
                    setPhase("rest");
                    setTimeLeft(15);
                  } else {
                    advanceExercise();
                  }
                }}
              >
                <Text style={[styles.skipText, { color: colors.textSecondary }]}>Skip</Text>
              </Pressable>
              <Pressable
                style={[styles.nextBtn, { backgroundColor: colors.purple }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  advanceExercise();
                }}
              >
                <Text style={styles.nextBtnText}>
                  {currentExerciseIdx === exercises.length - 1 ? "Finish" : "Next"}
                </Text>
                <AppIcon name="arrow-forward" size={18} color="white" />
              </Pressable>
            </View>

            {/* Honor system */}
            <Pressable
              style={styles.honorBtn}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                completeWorkout(false);
              }}
            >
              <Text style={[styles.honorText, { color: colors.textMuted }]}>
                I did it my way (+20 LTK)
              </Text>
            </Pressable>
          </>
        ) : (
          <View style={styles.doneContent}>
            <AppIcon name="trophy" size={72} color={colors.amber} />
            <Text style={[styles.doneTitle, { color: colors.textPrimary }]}>Workout Complete!</Text>
            <Text style={[styles.doneSub, { color: colors.textSecondary }]}>
              {formatTime(elapsed)} total time
            </Text>
          </View>
        )}
      </View>

      <LTKRewardModal
        visible={showReward}
        ltkAmount={rewardAmount}
        title="Workout Done!"
        message={rewardAmount === 50 ? "Full session verified! Amazing work." : "Good job! Keep building that habit."}
        onClose={() => {
          setShowReward(false);
          router.back();
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  closeBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  topInfo: { flex: 1 },
  programLabel: { fontSize: 12, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.5 },
  dayLabel: { fontSize: 14, fontWeight: "600" },
  elapsedTime: { fontSize: 16, fontWeight: "700", fontVariant: ["tabular-nums"] },
  progressBg: { height: 4, marginHorizontal: 16, borderRadius: 2 },
  progressFill: { height: "100%", borderRadius: 2 },
  content: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 24, gap: 16 },
  exerciseCounter: { fontSize: 13, fontWeight: "600" },
  phaseBadge: { paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20 },
  phaseText: { fontSize: 12, fontWeight: "800", letterSpacing: 2 },
  exerciseName: { fontSize: 28, fontWeight: "900", textAlign: "center" },
  setsReps: { fontSize: 18, fontWeight: "700" },
  timerCircle: { width: 160, height: 160, borderRadius: 80, borderWidth: 4, alignItems: "center", justifyContent: "center" },
  timerText: { fontSize: 56, fontWeight: "900", fontVariant: ["tabular-nums"] },
  timerSub: { fontSize: 14, fontWeight: "600" },
  instructions: { fontSize: 14, textAlign: "center", lineHeight: 22, paddingHorizontal: 16 },
  controls: { flexDirection: "row", gap: 14, marginTop: 8 },
  skipBtn: { paddingHorizontal: 20, paddingVertical: 14, borderRadius: 14, borderWidth: 1 },
  skipText: { fontSize: 15, fontWeight: "600" },
  nextBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 14 },
  nextBtnText: { color: "white", fontSize: 16, fontWeight: "700" },
  honorBtn: { paddingVertical: 8 },
  honorText: { fontSize: 13, textDecorationLine: "underline" },
  doneContent: { alignItems: "center", gap: 16 },
  doneTitle: { fontSize: 32, fontWeight: "900" },
  doneSub: { fontSize: 16 },
  errorText: { fontSize: 18, marginBottom: 20 },
  backBtnSm: { paddingHorizontal: 24, paddingVertical: 14, borderRadius: 14 },
});
