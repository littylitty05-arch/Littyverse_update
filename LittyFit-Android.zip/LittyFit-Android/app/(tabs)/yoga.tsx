import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useColors } from "@/hooks/useColors";
import BreathingCircle from "@/components/BreathingCircle";
import { YOGA_FLOWS } from "@/data/littyfit";

const LEVEL_COLORS: Record<string, string> = {
  beginner: "#10b981",
  intermediate: "#f59e0b",
  advanced: "#ef4444",
};

const RECOVERY_TOOLS = [
  { id: "rest", icon: "bed-outline", label: "Rest Day", sub: "Mark today as a recovery day", color: "#818cf8" },
  { id: "breathwork", icon: "partly-sunny-outline", label: "Breathwork", sub: "4-7-8 breathing technique", color: "#38bdf8" },
  { id: "cold", icon: "snow-outline", label: "Cold Exposure", sub: "Cold shower or ice bath", color: "#22d3ee" },
  { id: "stretch", icon: "body-outline", label: "Mobility Work", sub: "10 min full-body stretch", color: "#4ade80" },
  { id: "journal", icon: "book-outline", label: "Evening Shutdown", sub: "Brain dump + gratitude", color: "#f59e0b" },
  { id: "screen", icon: "phone-portrait-outline", label: "Screen Off", sub: "No screens 1hr before bed", color: "#a78bfa" },
] as const;

type RecoveryId = typeof RECOVERY_TOOLS[number]["id"];

const SLEEP_TIPS = [
  "Aim for 7–9 hours every night — no debate.",
  "Keep the same bedtime even on weekends.",
  "Cool your room to 65–68°F for optimal sleep.",
  "No caffeine after 2pm. Your adenosine receptors will thank you.",
  "Blue light exposure delays melatonin. Use Night Mode.",
  "Magnesium glycinate 30 min before bed can help sleep quality.",
];

const DEMO_SLEEP_WEEK = [7, 6, 8, 5, 9, 7, 8];
const DAY_LABELS = ["M", "T", "W", "T", "F", "S", "S"];

export default function RecoverTab() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const todayKey = new Date().toISOString().split("T")[0];

  const [recoveryChecked, setRecoveryChecked] = useState<Set<RecoveryId>>(new Set());
  const [sleepHours, setSleepHours] = useState<number | null>(null);
  const [stressLevel, setStressLevel] = useState<number | null>(null);
  const [showBreathing, setShowBreathing] = useState(false);
  const [breathCycles, setBreathCycles] = useState(0);

  const toggleRecovery = useCallback((id: RecoveryId) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (id === "breathwork") {
      setShowBreathing(!showBreathing);
    }
    setRecoveryChecked((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, [showBreathing]);

  const sleepTip = SLEEP_TIPS[new Date().getDay() % SLEEP_TIPS.length];
  const maxSleep = Math.max(...DEMO_SLEEP_WEEK);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPad + 90 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPad + 20 }]}>
        <Text style={[styles.appLabel, { color: colors.textMuted }]}>LittyFit</Text>
        <Text style={[styles.title, { color: colors.textPrimary }]}>Recover</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Recovery is where results are built.
        </Text>
      </View>

      <View style={styles.content}>
        {/* Sleep History Chart */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.sectionHead}>
            <View style={[styles.sectionIcon, { backgroundColor: "rgba(129,140,248,0.15)" }]}>
              <AppIcon name="moon" size={20} color="#818cf8" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Sleep Log</Text>
              <Text style={[styles.sectionSub, { color: colors.textMuted }]}>
                {sleepHours ? `${sleepHours}h logged tonight` : "How many hours did you sleep?"}
              </Text>
            </View>
            {sleepHours && (
              <View style={[styles.sleepBadge, {
                backgroundColor: sleepHours >= 7 ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.12)",
                borderColor: sleepHours >= 7 ? colors.green : colors.red,
              }]}>
                <Text style={[styles.sleepBadgeText, { color: sleepHours >= 7 ? colors.green : colors.red }]}>
                  {sleepHours >= 7 ? "Optimal" : "Low"}
                </Text>
              </View>
            )}
          </View>

          {/* 7-day sleep bar chart */}
          <View style={styles.sleepChart}>
            <Text style={[styles.chartLabel, { color: colors.textMuted }]}>Last 7 Days</Text>
            <View style={styles.chartBars}>
              {DEMO_SLEEP_WEEK.map((h, i) => {
                const isToday = i === 6;
                const barColor = h >= 7 ? "#818cf8" : h >= 6 ? colors.amber : colors.red;
                return (
                  <View key={i} style={styles.chartBarCol}>
                    <View style={[styles.chartBarBg, { backgroundColor: colors.secondary }]}>
                      <View
                        style={[
                          styles.chartBarFill,
                          {
                            height: `${(h / maxSleep) * 100}%`,
                            backgroundColor: barColor,
                            opacity: isToday ? 1 : 0.6,
                          },
                        ]}
                      />
                    </View>
                    <Text style={[styles.chartDayLabel, { color: isToday ? "#818cf8" : colors.textMuted, fontWeight: isToday ? "800" : "400" }]}>
                      {DAY_LABELS[i]}
                    </Text>
                    <Text style={[styles.chartHourLabel, { color: barColor }]}>{h}h</Text>
                  </View>
                );
              })}
            </View>
          </View>

          <View style={styles.sleepRow}>
            {[5, 6, 7, 8, 9, 10].map((h) => (
              <Pressable
                key={h}
                style={[
                  styles.sleepBtn,
                  {
                    backgroundColor: sleepHours === h ? "#818cf8" : colors.secondary,
                    borderColor: sleepHours === h ? "#818cf8" : colors.border,
                  },
                ]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setSleepHours(h);
                }}
              >
                <Text style={[styles.sleepBtnText, { color: sleepHours === h ? "white" : colors.textSecondary }]}>
                  {h}h
                </Text>
              </Pressable>
            ))}
          </View>
          <View style={[styles.tipCard, { backgroundColor: "rgba(129,140,248,0.06)", borderColor: "rgba(129,140,248,0.2)" }]}>
            <AppIcon name="bulb-outline" size={14} color="#818cf8" />
            <Text style={[styles.tipText, { color: colors.textSecondary }]}>{sleepTip}</Text>
          </View>
        </View>

        {/* Stress Level */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.sectionHead}>
            <View style={[styles.sectionIcon, { backgroundColor: "rgba(245,158,11,0.12)" }]}>
              <AppIcon name="pulse" size={20} color={colors.amber} />
            </View>
            <View>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Stress Level</Text>
              <Text style={[styles.sectionSub, { color: colors.textMuted }]}>How's your nervous system?</Text>
            </View>
          </View>
          <View style={styles.stressRow}>
            {[
              { val: 1, label: "Low", color: "#10b981" },
              { val: 2, label: "Mild", color: "#84cc16" },
              { val: 3, label: "Moderate", color: "#f59e0b" },
              { val: 4, label: "High", color: "#f97316" },
              { val: 5, label: "Max", color: "#ef4444" },
            ].map(({ val, label, color }) => (
              <Pressable
                key={val}
                style={[
                  styles.stressBtn,
                  {
                    backgroundColor: stressLevel === val ? `${color}25` : colors.secondary,
                    borderColor: stressLevel === val ? color : colors.border,
                  },
                ]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setStressLevel(val);
                }}
              >
                <Text style={[styles.stressBtnNum, { color: stressLevel === val ? color : colors.textMuted }]}>{val}</Text>
                <Text style={[styles.stressBtnLabel, { color: stressLevel === val ? color : colors.textMuted }]}>{label}</Text>
              </Pressable>
            ))}
          </View>
          {stressLevel && stressLevel >= 4 && (
            <View style={[styles.stressAlert, { backgroundColor: "rgba(239,68,68,0.08)", borderColor: "rgba(239,68,68,0.25)" }]}>
              <AppIcon name="warning-outline" size={14} color={colors.red} />
              <Text style={[styles.stressAlertText, { color: colors.textSecondary }]}>
                High stress spikes cortisol. Prioritize sleep and breathwork today.
              </Text>
            </View>
          )}
        </View>

        {/* Breathing Exercise */}
        {showBreathing && (
          <View style={[styles.section, { backgroundColor: "rgba(56,189,248,0.06)", borderColor: "rgba(56,189,248,0.25)" }]}>
            <View style={styles.sectionHead}>
              <View style={[styles.sectionIcon, { backgroundColor: "rgba(56,189,248,0.15)" }]}>
                <AppIcon name="partly-sunny-outline" size={20} color="#38bdf8" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>4-7-8 Breathing</Text>
                <Text style={[styles.sectionSub, { color: colors.textMuted }]}>
                  {breathCycles > 0 ? `${breathCycles} cycle${breathCycles > 1 ? "s" : ""} complete` : "Tap the circle to begin"}
                </Text>
              </View>
              <Pressable onPress={() => setShowBreathing(false)}>
                <AppIcon name="close" size={20} color={colors.textMuted} />
              </Pressable>
            </View>
            <View style={{ alignItems: "center", paddingVertical: 16 }}>
              <BreathingCircle
                size={160}
                primaryColor="#38bdf8"
                onCycleComplete={() => setBreathCycles((c) => c + 1)}
              />
            </View>
            <View style={styles.breathSteps}>
              {[
                { phase: "Inhale", dur: "4s", color: "#38bdf8" },
                { phase: "Hold", dur: "7s", color: "#818cf8" },
                { phase: "Exhale", dur: "8s", color: "#4ade80" },
              ].map((s) => (
                <View key={s.phase} style={[styles.breathStep, { backgroundColor: `${s.color}12`, borderColor: `${s.color}30` }]}>
                  <Text style={[styles.breathPhase, { color: s.color }]}>{s.phase}</Text>
                  <Text style={[styles.breathDur, { color: colors.textMuted }]}>{s.dur}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Recovery Protocol */}
        <View>
          <Text style={[styles.blockTitle, { color: colors.textPrimary }]}>Recovery Protocol</Text>
          <Text style={[styles.blockSub, { color: colors.textMuted }]}>
            {recoveryChecked.size}/{RECOVERY_TOOLS.length} actions complete
          </Text>
          <View style={styles.recoveryGrid}>
            {RECOVERY_TOOLS.map((tool) => {
              const done = recoveryChecked.has(tool.id);
              return (
                <Pressable
                  key={tool.id}
                  style={[
                    styles.recoveryCard,
                    {
                      backgroundColor: done ? `${tool.color}15` : colors.card,
                      borderColor: done ? tool.color : colors.border,
                    },
                  ]}
                  onPress={() => toggleRecovery(tool.id)}
                >
                  <View style={[styles.recoveryIcon, { backgroundColor: done ? `${tool.color}25` : colors.secondary }]}>
                    <AppIcon name={tool.icon as any} size={20} color={done ? tool.color : colors.textMuted} />
                  </View>
                  <Text style={[styles.recoveryLabel, { color: done ? colors.textPrimary : colors.textSecondary }]}>
                    {tool.label}
                  </Text>
                  <Text style={[styles.recoverySub, { color: colors.textMuted }]}>{tool.sub}</Text>
                  <View style={[styles.recoveryCheck, { backgroundColor: done ? tool.color : colors.border }]}>
                    {done && <AppIcon name="checkmark" size={10} color="white" />}
                  </View>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Yoga Flows */}
        <View>
          <Text style={[styles.blockTitle, { color: colors.textPrimary }]}>Yoga Flows</Text>
          <Text style={[styles.blockSub, { color: colors.textMuted }]}>Flow, breathe, earn +25 LTK per session</Text>
          <View style={styles.flowList}>
            {YOGA_FLOWS.map((flow) => {
              const levelColor = LEVEL_COLORS[flow.level];
              return (
                <Pressable
                  key={flow.id}
                  style={[styles.flowCard, { backgroundColor: colors.card, borderColor: colors.border }]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    router.push({ pathname: "/yoga-session", params: { flowId: flow.id } });
                  }}
                >
                  <View style={styles.flowLeft}>
                    <Text style={styles.flowEmoji}>{flow.emoji}</Text>
                    <View style={styles.flowInfo}>
                      <Text style={[styles.flowName, { color: colors.textPrimary }]}>{flow.name}</Text>
                      <Text style={[styles.flowMeta, { color: colors.textMuted }]}>
                        {flow.duration} · {flow.poses.length} poses
                      </Text>
                    </View>
                  </View>
                  <View style={styles.flowRight}>
                    <View style={[styles.levelBadge, { backgroundColor: `${levelColor}20`, borderColor: `${levelColor}50` }]}>
                      <Text style={[styles.levelText, { color: levelColor }]}>{flow.level}</Text>
                    </View>
                    <View style={[styles.ltkTag, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                      <Text style={[styles.ltkTagText, { color: colors.amber }]}>+25 LTK</Text>
                    </View>
                  </View>
                </Pressable>
              );
            })}
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  appLabel: { fontSize: 11, textTransform: "uppercase", letterSpacing: 1.5, fontWeight: "700", marginBottom: 4 },
  title: { fontSize: 28, fontWeight: "900" },
  subtitle: { fontSize: 14, marginTop: 4 },
  content: { paddingHorizontal: 20, gap: 22 },
  section: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 14 },
  sectionHead: { flexDirection: "row", alignItems: "center", gap: 12 },
  sectionIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  sectionTitle: { fontSize: 16, fontWeight: "800" },
  sectionSub: { fontSize: 12, marginTop: 2 },
  sleepBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 12, borderWidth: 1 },
  sleepBadgeText: { fontSize: 12, fontWeight: "700" },
  sleepChart: { gap: 8 },
  chartLabel: { fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  chartBars: { flexDirection: "row", gap: 6, height: 70, alignItems: "flex-end" },
  chartBarCol: { flex: 1, alignItems: "center", gap: 3 },
  chartBarBg: { width: "100%", flex: 1, borderRadius: 6, overflow: "hidden", justifyContent: "flex-end" },
  chartBarFill: { width: "100%", borderRadius: 6 },
  chartDayLabel: { fontSize: 10 },
  chartHourLabel: { fontSize: 9, fontWeight: "700" },
  sleepRow: { flexDirection: "row", gap: 8 },
  sleepBtn: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 12, borderWidth: 1 },
  sleepBtnText: { fontSize: 13, fontWeight: "700" },
  tipCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 12, borderWidth: 1 },
  tipText: { fontSize: 12, flex: 1, lineHeight: 18 },
  stressRow: { flexDirection: "row", gap: 8 },
  stressBtn: { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 12, borderWidth: 1, gap: 4 },
  stressBtnNum: { fontSize: 18, fontWeight: "900" },
  stressBtnLabel: { fontSize: 9, textTransform: "uppercase", letterSpacing: 0.3 },
  stressAlert: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 12, borderWidth: 1 },
  stressAlertText: { flex: 1, fontSize: 12, lineHeight: 18 },
  breathSteps: { flexDirection: "row", gap: 8 },
  breathStep: { flex: 1, alignItems: "center", padding: 10, borderRadius: 12, borderWidth: 1, gap: 3 },
  breathPhase: { fontSize: 12, fontWeight: "800" },
  breathDur: { fontSize: 11 },
  blockTitle: { fontSize: 18, fontWeight: "900", marginBottom: 4 },
  blockSub: { fontSize: 12, marginBottom: 14 },
  recoveryGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  recoveryCard: { width: "47%", padding: 14, borderRadius: 18, borderWidth: 1.5, gap: 6, position: "relative" },
  recoveryIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  recoveryLabel: { fontSize: 13, fontWeight: "700" },
  recoverySub: { fontSize: 11 },
  recoveryCheck: { position: "absolute", top: 10, right: 10, width: 18, height: 18, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  flowList: { gap: 12 },
  flowCard: { borderRadius: 20, borderWidth: 1, padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  flowLeft: { flexDirection: "row", alignItems: "center", gap: 14, flex: 1 },
  flowEmoji: { fontSize: 32 },
  flowInfo: { flex: 1 },
  flowName: { fontSize: 15, fontWeight: "700" },
  flowMeta: { fontSize: 12, marginTop: 3 },
  flowRight: { alignItems: "flex-end", gap: 6 },
  levelBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, borderWidth: 1 },
  levelText: { fontSize: 11, fontWeight: "700", textTransform: "capitalize" },
  ltkTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  ltkTagText: { fontSize: 12, fontWeight: "800" },
});
