import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  Alert,
  Linking,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import ProgressRing from "@/components/ProgressRing";
import { useQuery } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { apiFetch } from "@/lib/api";

function getLevelInfo(streak: number, totalWorkouts: number, totalLtk: number) {
  const xp = streak * 10 + totalWorkouts * 5 + Math.floor(totalLtk / 10);
  const thresholds = [
    { level: 50, xp: 5000, title: "Longevity Master" },
    { level: 20, xp: 1500, title: "Elite Performance" },
    { level: 10, xp: 500, title: "Optimized Human" },
    { level: 5, xp: 200, title: "Stable Routine" },
    { level: 1, xp: 0, title: "Base Activated" },
  ];
  const found = thresholds.find((t) => xp >= t.xp) ?? thresholds[thresholds.length - 1];
  const nextThreshold = thresholds[thresholds.indexOf(found) - 1];
  const progress = nextThreshold
    ? Math.min((xp - found.xp) / (nextThreshold.xp - found.xp), 1)
    : 1;
  return { level: found.level, title: found.title, xp, progress };
}

const ACTION_TYPE_META: Record<string, { icon: string; color: string }> = {
  workout: { icon: "barbell-outline", color: "#a78bfa" },
  checkin: { icon: "flame-outline", color: "#f97316" },
  yoga: { icon: "moon-outline", color: "#818cf8" },
  hydration: { icon: "water-outline", color: "#38bdf8" },
  nutrition: { icon: "leaf-outline", color: "#4ade80" },
  default: { icon: "star-outline", color: "#f59e0b" },
};

export default function ProfileTab() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuth();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const { data: stats } = useQuery({
    queryKey: ["littyfit-stats"],
    queryFn: async () => {
      const res = await apiFetch("/api/littyfit/stats");
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user,
  });

  const { data: balance } = useQuery({
    queryKey: ["ltk-balance", user?.id],
    queryFn: async () => {
      const res = await apiFetch(`/api/ltk/balance/${user?.id}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user?.id,
  });

  const { data: history } = useQuery({
    queryKey: ["ltk-history", user?.id],
    queryFn: async () => {
      const res = await apiFetch(`/api/ltk/history/${user?.id}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user?.id,
  });

  const initials = (user?.firstName ?? user?.username ?? "LF").slice(0, 2).toUpperCase();

  const handleLogout = () => {
    if (Platform.OS === "web") {
      logout().then(() => router.replace("/login"));
      return;
    }
    Alert.alert("Sign Out", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          await logout();
          router.replace("/login");
        },
      },
    ]);
  };

  const streak = user?.isDemo ? 7 : (stats?.streak ?? 0);
  const totalWorkouts = user?.isDemo ? 14 : (stats?.totalWorkouts ?? 0);
  const totalYoga = stats?.totalYoga ?? (user?.isDemo ? 5 : 0);
  const totalLtk = user?.isDemo ? 350 : (stats?.totalLtk ?? 0);
  const ltkBalance = balance?.balance ?? (user?.isDemo ? 350 : 0);
  const { level, title: levelTitle, xp, progress: levelProgress } = getLevelInfo(streak, totalWorkouts, totalLtk);

  const recentHistory = (history ?? []).slice(0, 10);

  const ACHIEVEMENTS = [
    { id: "first_workout", label: "First Rep", icon: "barbell-outline", color: colors.purpleLight, desc: "Complete 1 workout", unlocked: totalWorkouts >= 1 },
    { id: "streak_3", label: "3-Day Streak", icon: "flame-outline", color: "#f97316", desc: "3 days in a row", unlocked: streak >= 3 },
    { id: "streak_7", label: "Week Warrior", icon: "trophy", color: colors.amber, desc: "7-day streak", unlocked: streak >= 7 },
    { id: "workouts_10", label: "10 Workouts", icon: "barbell-outline", color: "#a78bfa", desc: "Complete 10 sessions", unlocked: totalWorkouts >= 10 },
    { id: "yoga_5", label: "Yoga Flow", icon: "moon-outline", color: "#818cf8", desc: "5 yoga sessions", unlocked: totalYoga >= 5 },
    { id: "ltk_100", label: "LTK Earner", icon: "star", color: colors.amber, desc: "Earn 100 LTK", unlocked: totalLtk >= 100 },
    { id: "ltk_500", label: "LTK Master", icon: "star", color: "#fbbf24", desc: "Earn 500 LTK", unlocked: totalLtk >= 500 },
    { id: "level_5", label: "Level 5", icon: "trending-up", color: colors.green, desc: "Reach Level 5", unlocked: level >= 5 },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPad + 80 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPad + 20 }]}>
        {/* Avatar */}
        <View style={[styles.avatar, { backgroundColor: colors.purple }]}>
          <Text style={styles.avatarText}>{initials}</Text>
        </View>
        <Text style={[styles.name, { color: colors.textPrimary }]}>
          {user?.firstName ?? user?.username}
        </Text>
        <Text style={[styles.email, { color: colors.textSecondary }]}>{user?.email}</Text>

        {/* LTK Balance */}
        <View style={[styles.balanceCard, { backgroundColor: "rgba(245,158,11,0.1)", borderColor: "rgba(245,158,11,0.3)" }]}>
          <AppIcon name="star" size={20} color={colors.amber} />
          <Text style={[styles.balanceAmount, { color: colors.amber }]}>
            {ltkBalance.toLocaleString()}
          </Text>
          <Text style={[styles.balanceUnit, { color: colors.amber + "cc" }]}>LTK</Text>
        </View>

        {/* Level System */}
        <View style={[styles.levelCard, { backgroundColor: "rgba(124,58,237,0.1)", borderColor: "rgba(124,58,237,0.3)" }]}>
          <View style={styles.levelTop}>
            <ProgressRing
              progress={levelProgress}
              size={60}
              strokeWidth={6}
              color={colors.purpleLight}
            >
              <Text style={[styles.levelNum, { color: colors.textPrimary }]}>{level}</Text>
            </ProgressRing>
            <View style={{ flex: 1 }}>
              <Text style={[styles.levelTitle, { color: colors.textPrimary }]}>{levelTitle}</Text>
              <Text style={[styles.levelSub, { color: colors.textMuted }]}>Human OS · {xp} XP total</Text>
            </View>
          </View>
          <View style={styles.levelTiers}>
            {[
              { l: 1, t: "Base" },
              { l: 5, t: "Stable" },
              { l: 10, t: "Optimized" },
              { l: 20, t: "Elite" },
              { l: 50, t: "Master" },
            ].map((tier) => (
              <View key={tier.l} style={styles.tierItem}>
                <View style={[styles.tierDot, { backgroundColor: level >= tier.l ? colors.purpleLight : colors.border }]} />
                <Text style={[styles.tierLabel, { color: level >= tier.l ? colors.purpleLight : colors.textMuted }]}>
                  Lv{tier.l}
                </Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      <View style={styles.content}>
        {/* Demo Banner */}
        {user?.isDemo && (
          <Pressable
            style={[styles.demoBanner, { backgroundColor: "rgba(245,158,11,0.12)", borderColor: colors.amber }]}
            onPress={async () => {
              await logout();
              router.replace("/login");
            }}
          >
            <AppIcon name="eye-outline" size={18} color={colors.amber} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.demoBannerTitle, { color: colors.amber }]}>Demo Mode</Text>
              <Text style={[styles.demoBannerSub, { color: colors.textMuted }]}>Sign in to earn real LTK tokens</Text>
            </View>
            <Text style={[styles.demoBannerExit, { color: colors.purpleLight }]}>Sign In →</Text>
          </Pressable>
        )}

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          {[
            { label: "Workouts", value: totalWorkouts, icon: "barbell-outline", color: colors.purpleLight },
            { label: "Yoga", value: totalYoga, icon: "moon-outline", color: "#818cf8" },
            { label: "Streak", value: `${streak}d`, icon: "flame-outline", color: "#f97316" },
            { label: "LTK Earned", value: totalLtk, icon: "star-outline", color: colors.amber },
          ].map((stat) => (
            <View
              key={stat.label}
              style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
            >
              <AppIcon name={stat.icon as any} size={24} color={stat.color} />
              <Text style={[styles.statValue, { color: colors.textPrimary }]}>{stat.value}</Text>
              <Text style={[styles.statLabel, { color: colors.textMuted }]}>{stat.label}</Text>
            </View>
          ))}
        </View>

        {/* Achievement Badges */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Achievements</Text>
          <Text style={[styles.sectionSub, { color: colors.textMuted }]}>
            {ACHIEVEMENTS.filter((a) => a.unlocked).length}/{ACHIEVEMENTS.length} unlocked
          </Text>
          <View style={styles.badgesGrid}>
            {ACHIEVEMENTS.map((badge) => (
              <View
                key={badge.id}
                style={[
                  styles.badge,
                  {
                    backgroundColor: badge.unlocked ? `${badge.color}14` : colors.card,
                    borderColor: badge.unlocked ? `${badge.color}50` : colors.border,
                    opacity: badge.unlocked ? 1 : 0.45,
                  },
                ]}
              >
                <View style={[styles.badgeIcon, { backgroundColor: badge.unlocked ? `${badge.color}22` : colors.secondary }]}>
                  <AppIcon name={badge.icon as any} size={20} color={badge.unlocked ? badge.color : colors.textMuted} />
                </View>
                <Text style={[styles.badgeLabel, { color: badge.unlocked ? colors.textPrimary : colors.textMuted }]}>
                  {badge.label}
                </Text>
                <Text style={[styles.badgeDesc, { color: colors.textMuted }]}>{badge.desc}</Text>
                {badge.unlocked && (
                  <View style={[styles.badgeCheck, { backgroundColor: badge.color }]}>
                    <AppIcon name="checkmark" size={8} color="white" />
                  </View>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* View Progress */}
        <Pressable
          style={[styles.progressBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => {
            if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            router.push("/progress");
          }}
        >
          <View style={[styles.progressIcon, { backgroundColor: "rgba(124,58,237,0.15)" }]}>
            <AppIcon name="trending-up" size={22} color={colors.purpleLight} />
          </View>
          <Text style={[styles.progressText, { color: colors.textPrimary }]}>View Full Progress</Text>
          <AppIcon name="chevron-forward" size={20} color={colors.textMuted} />
        </Pressable>

        {/* LTK History */}
        {recentHistory.length > 0 ? (
          <View style={[styles.historyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>LTK Earnings</Text>
            {recentHistory.map((item: any, i: number) => {
              const actionKey = (item.actionType ?? "").toLowerCase();
              const meta = ACTION_TYPE_META[actionKey] ?? ACTION_TYPE_META.default;
              return (
                <View
                  key={i}
                  style={[styles.historyRow, { borderTopColor: colors.border, borderTopWidth: i === 0 ? 0 : 1 }]}
                >
                  <View style={[styles.historyIcon, { backgroundColor: `${meta.color}14` }]}>
                    <AppIcon name={meta.icon as any} size={16} color={meta.color} />
                  </View>
                  <View style={styles.historyInfo}>
                    <Text style={[styles.historyDesc, { color: colors.textPrimary }]}>
                      {item.description ?? item.actionType ?? "Reward"}
                    </Text>
                    <Text style={[styles.historyDate, { color: colors.textMuted }]}>
                      {new Date(item.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </Text>
                  </View>
                  <View style={[styles.historyPoints, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                    <AppIcon name="star" size={11} color={colors.amber} />
                    <Text style={[styles.historyPtsText, { color: colors.amber }]}>+{item.points}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        ) : user?.isDemo ? (
          <View style={[styles.historyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>LTK Earnings</Text>
            {[
              { desc: "Day Streak Bonus", actionType: "checkin", points: 50, date: "Apr 19" },
              { desc: "Workout Complete", actionType: "workout", points: 75, date: "Apr 18" },
              { desc: "Hydration Goal", actionType: "hydration", points: 10, date: "Apr 17" },
              { desc: "Yoga Flow", actionType: "yoga", points: 25, date: "Apr 16" },
              { desc: "Workout Complete", actionType: "workout", points: 75, date: "Apr 15" },
            ].map((item, i) => {
              const meta = ACTION_TYPE_META[item.actionType] ?? ACTION_TYPE_META.default;
              return (
                <View key={i} style={[styles.historyRow, { borderTopColor: colors.border, borderTopWidth: i === 0 ? 0 : 1 }]}>
                  <View style={[styles.historyIcon, { backgroundColor: `${meta.color}14` }]}>
                    <AppIcon name={meta.icon as any} size={16} color={meta.color} />
                  </View>
                  <View style={styles.historyInfo}>
                    <Text style={[styles.historyDesc, { color: colors.textPrimary }]}>{item.desc}</Text>
                    <Text style={[styles.historyDate, { color: colors.textMuted }]}>{item.date}</Text>
                  </View>
                  <View style={[styles.historyPoints, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                    <AppIcon name="star" size={11} color={colors.amber} />
                    <Text style={[styles.historyPtsText, { color: colors.amber }]}>+{item.points}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        ) : null}

        {/* Littyverse Hub */}
        <View style={[styles.littyHubCard, { backgroundColor: "rgba(124,58,237,0.08)", borderColor: "rgba(124,58,237,0.3)" }]}>
          <View style={styles.littyHubHeader}>
            <View style={[styles.littyHubIcon, { backgroundColor: colors.purple }]}>
              <AppIcon name="globe-outline" size={22} color="white" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.littyHubTitle, { color: colors.textPrimary }]}>Littyverse</Text>
              <Text style={[styles.littyHubSub, { color: colors.textMuted }]}>littyverse.com</Text>
            </View>
          </View>
          <Text style={[styles.littyHubDesc, { color: colors.textSecondary }]}>
            LittyFit is part of the Littyverse ecosystem. The LTK tokens you earn here live on your Littyverse account and can be spent across the entire platform.
          </Text>
          <View style={styles.littyHubBtns}>
            <Pressable
              style={[styles.littyHubBtn, { backgroundColor: colors.purple, flex: 1 }]}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                Linking.openURL("https://www.littyverse.com");
              }}
            >
              <AppIcon name="globe-outline" size={16} color="white" />
              <Text style={styles.littyHubBtnText}>Visit Littyverse</Text>
            </Pressable>
            <Pressable
              style={[styles.littyHubBtn, { backgroundColor: "rgba(245,158,11,0.15)", borderWidth: 1, borderColor: "rgba(245,158,11,0.4)", flex: 1 }]}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                Linking.openURL("https://www.littyverse.com/ltk");
              }}
            >
              <AppIcon name="star" size={16} color={colors.amber} />
              <Text style={[styles.littyHubBtnText, { color: colors.amber }]}>Spend LTK</Text>
            </Pressable>
          </View>
          <Pressable
            style={[styles.littyHubBtn, { backgroundColor: "rgba(74,222,128,0.12)", borderWidth: 1, borderColor: "rgba(74,222,128,0.35)" }]}
            onPress={() => {
              if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              Linking.openURL("https://littyverse-merch.printify.me/category/food-health-beauty");
            }}
          >
            <Text style={{ fontSize: 16 }}>💊</Text>
            <Text style={[styles.littyHubBtnText, { color: colors.green }]}>Shop Supplements</Text>
          </Pressable>
        </View>

        {/* Logout */}
        <Pressable
          style={[styles.logoutBtn, { backgroundColor: "rgba(239,68,68,0.1)", borderColor: colors.red }]}
          onPress={handleLogout}
        >
          <AppIcon name="log-out-outline" size={20} color={colors.red} />
          <Text style={[styles.logoutText, { color: colors.red }]}>Sign Out</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { alignItems: "center", paddingHorizontal: 20, paddingBottom: 24, gap: 8 },
  avatar: { width: 88, height: 88, borderRadius: 44, alignItems: "center", justifyContent: "center", marginBottom: 8 },
  avatarText: { fontSize: 32, fontWeight: "900", color: "white" },
  name: { fontSize: 24, fontWeight: "800" },
  email: { fontSize: 14 },
  balanceCard: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 20, borderWidth: 1, marginTop: 8 },
  balanceAmount: { fontSize: 28, fontWeight: "900" },
  balanceUnit: { fontSize: 16, fontWeight: "700" },
  content: { paddingHorizontal: 20, gap: 20 },
  sectionTitle: { fontSize: 18, fontWeight: "900", marginBottom: 4 },
  sectionSub: { fontSize: 12, marginBottom: 14 },
  statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  statCard: { width: "47%", padding: 16, borderRadius: 20, borderWidth: 1, alignItems: "center", gap: 6 },
  statValue: { fontSize: 24, fontWeight: "900" },
  statLabel: { fontSize: 12, textTransform: "uppercase", letterSpacing: 0.5 },
  badgesGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  badge: { width: "47%", padding: 12, borderRadius: 18, borderWidth: 1, gap: 4, position: "relative" },
  badgeIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  badgeLabel: { fontSize: 12, fontWeight: "800", marginTop: 2 },
  badgeDesc: { fontSize: 10 },
  badgeCheck: { position: "absolute", top: 10, right: 10, width: 16, height: 16, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  progressBtn: { flexDirection: "row", alignItems: "center", gap: 14, padding: 16, borderRadius: 20, borderWidth: 1 },
  progressIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  progressText: { flex: 1, fontSize: 16, fontWeight: "600" },
  historyCard: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 4 },
  cardTitle: { fontSize: 17, fontWeight: "700", marginBottom: 8 },
  historyRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 11 },
  historyIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  historyInfo: { flex: 1 },
  historyDesc: { fontSize: 14, fontWeight: "600" },
  historyDate: { fontSize: 12, marginTop: 2 },
  historyPoints: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 10 },
  historyPtsText: { fontSize: 14, fontWeight: "800" },
  logoutBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, padding: 16, borderRadius: 20, borderWidth: 1 },
  logoutText: { fontSize: 16, fontWeight: "700" },
  littyHubCard: { borderRadius: 20, borderWidth: 1, padding: 18, gap: 14 },
  littyHubHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  littyHubIcon: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  littyHubTitle: { fontSize: 18, fontWeight: "900" },
  littyHubSub: { fontSize: 12, marginTop: 2 },
  littyHubDesc: { fontSize: 13, lineHeight: 20 },
  littyHubBtns: { flexDirection: "row", gap: 10 },
  littyHubBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingVertical: 13, borderRadius: 14 },
  littyHubBtnText: { color: "white", fontWeight: "700", fontSize: 14 },
  demoBanner: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16, borderRadius: 20, borderWidth: 1.5 },
  demoBannerTitle: { fontSize: 14, fontWeight: "800" },
  demoBannerSub: { fontSize: 12, marginTop: 2 },
  demoBannerExit: { fontSize: 13, fontWeight: "700" },
  levelCard: { width: "100%", borderRadius: 20, borderWidth: 1, padding: 16, gap: 12, marginTop: 12 },
  levelTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  levelNum: { fontSize: 20, fontWeight: "900" },
  levelTitle: { fontSize: 16, fontWeight: "800" },
  levelSub: { fontSize: 12, marginTop: 2 },
  levelTiers: { flexDirection: "row", justifyContent: "space-between" },
  tierItem: { alignItems: "center", gap: 4 },
  tierDot: { width: 8, height: 8, borderRadius: 4 },
  tierLabel: { fontSize: 10, fontWeight: "700" },
});
