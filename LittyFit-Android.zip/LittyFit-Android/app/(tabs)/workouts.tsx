import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  Modal,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useQuery } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { apiFetch } from "@/lib/api";
import { WORKOUT_PROGRAMS } from "@/data/littyfit";

const LEVEL_COLORS: Record<string, string> = {
  beginner: "#10b981",
  intermediate: "#f59e0b",
  advanced: "#ef4444",
};

const DEMO_HISTORY = [
  { name: "Push Power", day: "Day 1", date: "Apr 19", difficulty: 4, duration: "42 min", pr: true },
  { name: "Leg Day Protocol", day: "Day 3", date: "Apr 17", difficulty: 3, duration: "55 min", pr: false },
  { name: "Pull & Core", day: "Day 2", date: "Apr 15", difficulty: 5, duration: "48 min", pr: true },
  { name: "Full Body Burn", day: "Day 1", date: "Apr 12", difficulty: 3, duration: "39 min", pr: false },
];

function DifficultyModal({
  visible,
  onClose,
  workoutName,
}: {
  visible: boolean;
  onClose: (rating: number) => void;
  workoutName: string;
}) {
  const colors = useColors();
  const [selected, setSelected] = useState(0);
  const labels = ["", "Easy", "Moderate", "Hard", "Intense", "Beast"];
  const labelColors = ["", "#10b981", "#84cc16", "#f59e0b", "#f97316", "#ef4444"];

  return (
    <Modal transparent visible={visible} animationType="fade">
      <View style={[drStyles.overlay]}>
        <View style={[drStyles.modal, { backgroundColor: colors.card }]}>
          <Text style={[drStyles.title, { color: colors.textPrimary }]}>Rate This Workout</Text>
          <Text style={[drStyles.sub, { color: colors.textMuted }]}>{workoutName}</Text>
          <View style={drStyles.stars}>
            {[1, 2, 3, 4, 5].map((s) => (
              <Pressable
                key={s}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setSelected(s);
                }}
              >
                <AppIcon
                  name={s <= selected ? "star" : "star-outline"}
                  size={38}
                  color={s <= selected ? colors.amber : colors.border}
                />
              </Pressable>
            ))}
          </View>
          {selected > 0 && (
            <Text style={[drStyles.label, { color: labelColors[selected] }]}>{labels[selected]}</Text>
          )}
          <Pressable
            style={[drStyles.btn, { backgroundColor: selected > 0 ? colors.purple : colors.secondary }]}
            onPress={() => { if (selected > 0) onClose(selected); }}
          >
            <Text style={[drStyles.btnText, { color: selected > 0 ? "white" : colors.textMuted }]}>
              {selected > 0 ? "Save & Earn LTK" : "Select a rating"}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const drStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", alignItems: "center", justifyContent: "center" },
  modal: { width: "85%", borderRadius: 24, padding: 28, alignItems: "center", gap: 14 },
  title: { fontSize: 20, fontWeight: "900" },
  sub: { fontSize: 14 },
  stars: { flexDirection: "row", gap: 8, marginVertical: 8 },
  label: { fontSize: 16, fontWeight: "800" },
  btn: { width: "100%", padding: 16, borderRadius: 16, alignItems: "center", marginTop: 4 },
  btnText: { fontSize: 15, fontWeight: "700" },
});

export default function WorkoutsTab() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [ratingVisible, setRatingVisible] = useState(false);
  const [ratingWorkout, setRatingWorkout] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const { data: profile, refetch } = useQuery({
    queryKey: ["littyfit-profile"],
    queryFn: async () => {
      const res = await apiFetch("/api/littyfit/profile");
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user,
  });

  const setProgram = async (programId: string) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await apiFetch("/api/littyfit/profile", {
        method: "POST",
        body: JSON.stringify({ currentProgramId: programId, currentDay: 1 }),
      });
      refetch();
    } catch {}
  };

  const totalWorkouts = user?.isDemo ? 14 : 0;

  return (
    <>
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ paddingBottom: bottomPad + 80 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, { paddingTop: topPad + 20 }]}>
          <Text style={[styles.title, { color: colors.purpleLight }]}>Train</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Choose your program, earn LTK
          </Text>
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          {[
            { label: "Workouts", value: totalWorkouts, color: colors.purpleLight },
            { label: "This Week", value: user?.isDemo ? 3 : 0, color: colors.amber },
            { label: "Active Program", value: profile?.currentProgramId ? "1" : "—", color: colors.green },
          ].map((s) => (
            <View key={s.label} style={[styles.statPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.statVal, { color: s.color }]}>{s.value}</Text>
              <Text style={[styles.statLbl, { color: colors.textMuted }]}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* History Toggle */}
        <Pressable
          style={[styles.historyToggle, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => setShowHistory(!showHistory)}
        >
          <View style={[styles.historyIconBg, { backgroundColor: "rgba(124,58,237,0.12)" }]}>
            <AppIcon name="calendar-outline" size={18} color={colors.purpleLight} />
          </View>
          <Text style={[styles.historyToggleText, { color: colors.textPrimary }]}>Workout History</Text>
          <AppIcon name={showHistory ? "chevron-up" : "chevron-down"} size={18} color={colors.textMuted} />
        </Pressable>

        {showHistory && (
          <View style={[styles.historyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {DEMO_HISTORY.map((h, i) => (
              <View
                key={i}
                style={[styles.historyRow, { borderTopColor: colors.border, borderTopWidth: i === 0 ? 0 : 1 }]}
              >
                <View style={[styles.historyDot, { backgroundColor: h.pr ? colors.amber : colors.secondary }]}>
                  {h.pr && <AppIcon name="trophy" size={12} color="white" />}
                </View>
                <View style={{ flex: 1 }}>
                  <View style={styles.historyTop}>
                    <Text style={[styles.historyName, { color: colors.textPrimary }]}>{h.name}</Text>
                    {h.pr && (
                      <View style={[styles.prBadge, { backgroundColor: "rgba(245,158,11,0.15)", borderColor: colors.amber }]}>
                        <Text style={[styles.prText, { color: colors.amber }]}>PR</Text>
                      </View>
                    )}
                  </View>
                  <Text style={[styles.historyMeta, { color: colors.textMuted }]}>
                    {h.day} · {h.duration} · {h.date}
                  </Text>
                </View>
                <View style={styles.starsRow}>
                  {[1, 2, 3, 4, 5].map((s) => (
                    <AppIcon key={s} name={s <= h.difficulty ? "star" : "star-outline"} size={11} color={s <= h.difficulty ? colors.amber : colors.border} />
                  ))}
                </View>
              </View>
            ))}
          </View>
        )}

        <View style={styles.list}>
          {WORKOUT_PROGRAMS.map((program) => {
            const isActive = profile?.currentProgramId === program.id;
            const isExpanded = expandedId === program.id;
            const levelColor = LEVEL_COLORS[program.level];

            return (
              <Pressable
                key={program.id}
                style={[
                  styles.programCard,
                  {
                    backgroundColor: colors.card,
                    borderColor: isActive ? colors.purple : colors.border,
                    borderWidth: isActive ? 2 : 1,
                  },
                ]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setExpandedId(isExpanded ? null : program.id);
                }}
              >
                <View style={styles.cardTop}>
                  <Text style={styles.emoji}>{program.emoji}</Text>
                  <View style={styles.cardInfo}>
                    <View style={styles.cardTitleRow}>
                      <Text style={[styles.programTitle, { color: colors.textPrimary }]}>
                        {program.title}
                      </Text>
                      {isActive && (
                        <View style={[styles.activeBadge, { backgroundColor: "rgba(124,58,237,0.2)", borderColor: colors.purple }]}>
                          <Text style={[styles.activeBadgeText, { color: colors.purpleLight }]}>Active</Text>
                        </View>
                      )}
                    </View>
                    <Text style={[styles.programSubtitle, { color: colors.textSecondary }]}>
                      {program.subtitle}
                    </Text>
                    <View style={styles.metaRow}>
                      <View style={[styles.levelBadge, { backgroundColor: levelColor + "22", borderColor: levelColor }]}>
                        <Text style={[styles.levelText, { color: levelColor }]}>
                          {program.level}
                        </Text>
                      </View>
                      <Text style={[styles.meta, { color: colors.textMuted }]}>
                        {program.daysPerWeek}x/wk · {program.weeks}wks
                      </Text>
                      <View style={styles.ltkRow}>
                        <AppIcon name="star" size={12} color={colors.amber} />
                        <Text style={[styles.ltkText, { color: colors.amber }]}>+{program.ltkReward}</Text>
                      </View>
                    </View>
                  </View>
                  <AppIcon
                    name={isExpanded ? "chevron-up" : "chevron-down"}
                    size={20}
                    color={colors.textMuted}
                  />
                </View>

                {isExpanded && (
                  <View style={styles.expanded}>
                    <View style={[styles.divider, { backgroundColor: colors.border }]} />
                    <Text style={[styles.daysLabel, { color: colors.textMuted }]}>
                      WORKOUT DAYS
                    </Text>
                    {program.days.map((day) => (
                      <Pressable
                        key={day.day}
                        style={[styles.dayRow, { backgroundColor: colors.secondary }]}
                        onPress={() => {
                          if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                          router.push({
                            pathname: "/workout-session",
                            params: { programId: program.id, day: day.day },
                          });
                        }}
                      >
                        <View style={[styles.dayNum, { backgroundColor: colors.purple }]}>
                          <Text style={styles.dayNumText}>{day.day}</Text>
                        </View>
                        <View style={styles.dayInfo}>
                          <Text style={[styles.dayName, { color: colors.textPrimary }]}>{day.name}</Text>
                          <Text style={[styles.dayExercises, { color: colors.textMuted }]}>
                            {day.exercises.length} exercises
                          </Text>
                        </View>
                        <Pressable
                          onPress={() => {
                            if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                            setRatingWorkout(`${program.title} — ${day.name}`);
                            setRatingVisible(true);
                          }}
                          style={[styles.rateBtn, { backgroundColor: "rgba(245,158,11,0.12)", borderColor: "rgba(245,158,11,0.3)" }]}
                        >
                          <AppIcon name="star" size={14} color={colors.amber} />
                          <Text style={[styles.rateBtnText, { color: colors.amber }]}>Rate</Text>
                        </Pressable>
                        <AppIcon name="play-circle" size={28} color={colors.purpleLight} />
                      </Pressable>
                    ))}

                    {!isActive && (
                      <Pressable
                        style={[styles.setActiveBtn, { backgroundColor: colors.purple }]}
                        onPress={() => setProgram(program.id)}
                      >
                        <Text style={styles.setActiveBtnText}>Set as My Program</Text>
                      </Pressable>
                    )}
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      <DifficultyModal
        visible={ratingVisible}
        workoutName={ratingWorkout}
        onClose={(rating) => {
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setRatingVisible(false);
        }}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12 },
  title: { fontSize: 28, fontWeight: "900" },
  subtitle: { fontSize: 14, marginTop: 4 },
  statsRow: { flexDirection: "row", gap: 10, paddingHorizontal: 20, marginBottom: 14 },
  statPill: { flex: 1, alignItems: "center", padding: 12, borderRadius: 14, borderWidth: 1, gap: 3 },
  statVal: { fontSize: 18, fontWeight: "900" },
  statLbl: { fontSize: 10, textTransform: "uppercase", letterSpacing: 0.3 },
  historyToggle: { flexDirection: "row", alignItems: "center", gap: 12, marginHorizontal: 20, marginBottom: 10, padding: 14, borderRadius: 16, borderWidth: 1 },
  historyIconBg: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  historyToggleText: { flex: 1, fontSize: 15, fontWeight: "600" },
  historyCard: { marginHorizontal: 20, marginBottom: 14, borderRadius: 20, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 4 },
  historyRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12 },
  historyDot: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  historyTop: { flexDirection: "row", alignItems: "center", gap: 6 },
  historyName: { fontSize: 14, fontWeight: "700" },
  historyMeta: { fontSize: 11, marginTop: 2 },
  prBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, borderWidth: 1 },
  prText: { fontSize: 10, fontWeight: "800" },
  starsRow: { flexDirection: "row", gap: 2 },
  list: { paddingHorizontal: 20, gap: 12 },
  programCard: { borderRadius: 20, overflow: "hidden" },
  cardTop: { flexDirection: "row", alignItems: "flex-start", padding: 16, gap: 12 },
  emoji: { fontSize: 36, marginTop: 2 },
  cardInfo: { flex: 1, gap: 4 },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
  programTitle: { fontSize: 16, fontWeight: "700" },
  activeBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8, borderWidth: 1 },
  activeBadgeText: { fontSize: 11, fontWeight: "700" },
  programSubtitle: { fontSize: 13 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  levelBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8, borderWidth: 1 },
  levelText: { fontSize: 11, fontWeight: "700", textTransform: "capitalize" },
  meta: { fontSize: 12 },
  ltkRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  ltkText: { fontSize: 12, fontWeight: "700" },
  expanded: { paddingHorizontal: 16, paddingBottom: 16, gap: 10 },
  divider: { height: 1, marginBottom: 4 },
  daysLabel: { fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1 },
  dayRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 14 },
  dayNum: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  dayNumText: { color: "white", fontWeight: "700", fontSize: 14 },
  dayInfo: { flex: 1 },
  dayName: { fontSize: 14, fontWeight: "600" },
  dayExercises: { fontSize: 12, marginTop: 1 },
  rateBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8, borderWidth: 1 },
  rateBtnText: { fontSize: 11, fontWeight: "700" },
  setActiveBtn: { padding: 14, borderRadius: 14, alignItems: "center", marginTop: 4 },
  setActiveBtnText: { color: "white", fontWeight: "700", fontSize: 15 },
});
