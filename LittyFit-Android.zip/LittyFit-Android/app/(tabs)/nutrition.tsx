import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  TextInput,
  ActivityIndicator,
  Animated,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import ProgressRing from "@/components/ProgressRing";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { apiFetch } from "@/lib/api";
import { DIET_PLANS } from "@/data/littyfit";
import LTKRewardModal from "@/components/LTKRewardModal";

function MacroRing({ label, value, target, color }: { label: string; value: number; target: number; color: string }) {
  const colors = useColors();
  const pct = Math.min(1, value / Math.max(1, target));
  return (
    <View style={macroStyles.container}>
      <ProgressRing progress={pct} size={74} strokeWidth={7} color={color}>
        <Text style={[macroStyles.val, { color: color }]}>{value}</Text>
      </ProgressRing>
      <Text style={[macroStyles.label, { color: colors.textMuted }]}>{label}</Text>
      <Text style={[macroStyles.target, { color: colors.textMuted }]}>/{target}</Text>
    </View>
  );
}

const macroStyles = StyleSheet.create({
  container: { alignItems: "center", gap: 4 },
  val: { fontSize: 14, fontWeight: "900" },
  label: { fontSize: 11, fontWeight: "700" },
  target: { fontSize: 10 },
});

export default function NutritionTab() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const today = new Date().toISOString().split("T")[0];
  const [glasses, setGlasses] = useState(0);
  const [calories, setCalories] = useState("");
  const [protein, setProtein] = useState("");
  const [carbs, setCarbs] = useState("");
  const [fats, setFats] = useState("");
  const [logging, setLogging] = useState(false);
  const [showReward, setShowReward] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(0);
  const [expandedPlan, setExpandedPlan] = useState<string | null>(null);

  const waterAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(waterAnim, {
      toValue: glasses / 8,
      useNativeDriver: false,
      tension: 60,
      friction: 8,
    }).start();
  }, [glasses]);

  const { data: nutrition, refetch } = useQuery({
    queryKey: ["nutrition", today],
    queryFn: async () => {
      const res = await apiFetch(`/api/littyfit/nutrition?date=${today}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user,
  });

  const { data: profile } = useQuery({
    queryKey: ["littyfit-profile"],
    queryFn: async () => {
      const res = await apiFetch("/api/littyfit/profile");
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (nutrition?.hydrationGlasses != null) {
      setGlasses(nutrition.hydrationGlasses);
    }
  }, [nutrition]);

  const fillGlass = async (index: number) => {
    const newCount = index + 1;
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setGlasses(newCount);
    try {
      const res = await apiFetch("/api/littyfit/nutrition", {
        method: "POST",
        body: JSON.stringify({
          date: today,
          hydrationGlasses: newCount,
          calories: nutrition?.calories ?? 0,
          protein: nutrition?.protein ?? 0,
          carbs: nutrition?.carbs ?? 0,
          fats: nutrition?.fats ?? 0,
        }),
      });
      const data = await res.json();
      if (data.newLtkEarned) {
        setRewardAmount(data.newLtkEarned);
        setShowReward(true);
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      refetch();
    } catch {}
  };

  const logFood = async () => {
    if (!calories && !protein && !carbs && !fats) return;
    setLogging(true);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await apiFetch("/api/littyfit/nutrition", {
        method: "POST",
        body: JSON.stringify({
          date: today,
          calories: parseInt(calories) || 0,
          protein: parseInt(protein) || 0,
          carbs: parseInt(carbs) || 0,
          fats: parseInt(fats) || 0,
          hydrationGlasses: glasses,
        }),
      });
      setCalories("");
      setProtein("");
      setCarbs("");
      setFats("");
      refetch();
      qc.invalidateQueries({ queryKey: ["littyfit-stats"] });
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {}
    setLogging(false);
  };

  const calorieTarget = profile?.calorieTarget ?? 2000;
  const proteinTarget = profile?.proteinTarget ?? 150;
  const calVal = nutrition?.calories ?? (user?.isDemo ? 1480 : 0);
  const protVal = nutrition?.protein ?? (user?.isDemo ? 112 : 0);
  const carbVal = nutrition?.carbs ?? (user?.isDemo ? 180 : 0);
  const fatVal = nutrition?.fats ?? (user?.isDemo ? 48 : 0);
  const waterGlasses = user?.isDemo ? 5 : glasses;

  const waterHeight = waterAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  return (
    <>
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ paddingBottom: bottomPad + 80 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, { paddingTop: topPad + 20 }]}>
          <Text style={[styles.title, { color: colors.green }]}>Fuel</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Track your macros & hydration
          </Text>
        </View>

        <View style={styles.content}>
          {/* Macro Rings */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.cardHeader}>
              <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Today's Macros</Text>
              <View style={[styles.calBadge, { backgroundColor: "rgba(124,58,237,0.15)" }]}>
                <Text style={[styles.calBadgeText, { color: colors.purpleLight }]}>
                  {calVal} / {calorieTarget} kcal
                </Text>
              </View>
            </View>
            <View style={styles.macroRings}>
              <MacroRing label="Protein" value={protVal} target={proteinTarget} color={colors.green} />
              <MacroRing label="Carbs" value={carbVal} target={250} color={colors.amber} />
              <MacroRing label="Fats" value={fatVal} target={70} color={colors.red} />
              <MacroRing label="Calories" value={calVal} target={calorieTarget} color={colors.purpleLight} />
            </View>
          </View>

          {/* Hydration */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.hydrationHeader}>
              <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Hydration</Text>
              {waterGlasses >= 8 && (
                <View style={[styles.goalBadge, { backgroundColor: "rgba(16,185,129,0.15)", borderColor: colors.green }]}>
                  <AppIcon name="checkmark-circle" size={14} color={colors.green} />
                  <Text style={[styles.goalBadgeText, { color: colors.green }]}>Goal! +10 LTK</Text>
                </View>
              )}
            </View>

            <View style={styles.waterTracker}>
              {/* Water bottle visual */}
              <View style={styles.bottleContainer}>
                <View style={[styles.bottle, { borderColor: "#3b82f6" + "60", backgroundColor: "rgba(59,130,246,0.07)" }]}>
                  <Animated.View
                    style={[
                      styles.waterFill,
                      {
                        height: waterHeight,
                        backgroundColor: "rgba(59,130,246,0.35)",
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.waterCount, { color: "#3b82f6" }]}>{waterGlasses}/8</Text>
              </View>

              {/* Glass buttons */}
              <View style={styles.glassesGrid}>
                {Array.from({ length: 8 }).map((_, i) => (
                  <Pressable
                    key={i}
                    style={[
                      styles.glassBtn,
                      {
                        backgroundColor: i < waterGlasses ? "rgba(59,130,246,0.2)" : colors.secondary,
                        borderColor: i < waterGlasses ? "#3b82f6" : colors.border,
                      },
                    ]}
                    onPress={() => fillGlass(i)}
                  >
                    <AppIcon
                      name="water-outline"
                      size={20}
                      color={i < waterGlasses ? "#3b82f6" : colors.textMuted}
                    />
                    <Text style={[styles.glassNum, { color: i < waterGlasses ? "#3b82f6" : colors.textMuted }]}>
                      {i + 1}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </View>

          {/* Log Food */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Log Today's Food</Text>
            <View style={styles.formGrid}>
              {[
                { label: "Calories", value: calories, onChange: setCalories, color: colors.purpleLight },
                { label: "Protein (g)", value: protein, onChange: setProtein, color: colors.green },
                { label: "Carbs (g)", value: carbs, onChange: setCarbs, color: colors.amber },
                { label: "Fats (g)", value: fats, onChange: setFats, color: colors.red },
              ].map((field) => (
                <View key={field.label} style={styles.formField}>
                  <Text style={[styles.fieldLabel, { color: field.color }]}>{field.label}</Text>
                  <TextInput
                    style={[styles.fieldInput, { backgroundColor: colors.secondary, borderColor: field.color + "40", color: colors.textPrimary }]}
                    value={field.value}
                    onChangeText={field.onChange}
                    placeholder="0"
                    placeholderTextColor={colors.textMuted}
                    keyboardType="numeric"
                  />
                </View>
              ))}
            </View>
            <Pressable
              style={[styles.logBtn, { backgroundColor: colors.green }]}
              onPress={logFood}
              disabled={logging}
            >
              {logging ? (
                <ActivityIndicator color="white" />
              ) : (
                <>
                  <AppIcon name="checkmark-circle" size={18} color="white" />
                  <Text style={styles.logBtnText}>Log Food</Text>
                </>
              )}
            </Pressable>
          </View>

          {/* Supplements Shop */}
          <Pressable
            style={[styles.suppCard, { backgroundColor: "rgba(74,222,128,0.07)", borderColor: "rgba(74,222,128,0.3)" }]}
            onPress={() => {
              if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              Linking.openURL("https://littyverse-merch.printify.me/category/food-health-beauty");
            }}
          >
            <View style={[styles.suppIconBg, { backgroundColor: "rgba(74,222,128,0.15)" }]}>
              <Text style={styles.suppEmoji}>💊</Text>
            </View>
            <View style={styles.suppInfo}>
              <Text style={[styles.suppTitle, { color: colors.textPrimary }]}>Littyverse Supplements</Text>
              <Text style={[styles.suppSub, { color: colors.textMuted }]}>
                Official health & wellness stack — built for the Littyverse lifestyle
              </Text>
              <View style={[styles.suppTag, { backgroundColor: "rgba(74,222,128,0.12)" }]}>
                <Text style={[styles.suppTagText, { color: colors.green }]}>Shop Now →</Text>
              </View>
            </View>
          </Pressable>

          {/* Diet Plans */}
          <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Diet Plans</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.plansScroll}>
            {DIET_PLANS.map((plan) => (
              <Pressable
                key={plan.id}
                style={[styles.planCard, { backgroundColor: colors.card, borderColor: expandedPlan === plan.id ? colors.green : colors.border }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setExpandedPlan(expandedPlan === plan.id ? null : plan.id);
                }}
              >
                <Text style={styles.planEmoji}>{plan.emoji}</Text>
                <Text style={[styles.planTitle, { color: colors.textPrimary }]}>{plan.title}</Text>
                <Text style={[styles.planSub, { color: colors.textSecondary }]}>{plan.subtitle}</Text>
                <Text style={[styles.planCals, { color: colors.green }]}>{plan.calories} kcal</Text>
              </Pressable>
            ))}
          </ScrollView>

          {expandedPlan && (() => {
            const plan = DIET_PLANS.find((p) => p.id === expandedPlan);
            if (!plan) return null;
            const day = plan.days[0];
            return (
              <View style={[styles.mealDetail, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>{plan.title} — Day Plan</Text>
                {[
                  { time: "Breakfast", meal: day.breakfast, icon: "sunny-outline", color: colors.amber },
                  { time: "Lunch", meal: day.lunch, icon: "partly-sunny-outline", color: colors.green },
                  { time: "Dinner", meal: day.dinner, icon: "moon-outline", color: "#818cf8" },
                  { time: "Snack", meal: day.snack, icon: "cafe-outline", color: colors.purpleLight },
                ].map((item) => (
                  <View key={item.time} style={[styles.mealRow, { borderLeftColor: item.color, borderLeftWidth: 3 }]}>
                    <View>
                      <Text style={[styles.mealTime, { color: item.color }]}>{item.time}</Text>
                      <Text style={[styles.mealText, { color: colors.textPrimary }]}>{item.meal}</Text>
                    </View>
                  </View>
                ))}
              </View>
            );
          })()}
        </View>
      </ScrollView>

      <LTKRewardModal
        visible={showReward}
        ltkAmount={rewardAmount}
        title="Hydration Goal!"
        message="You hit 8 glasses today. Stay hydrated!"
        onClose={() => setShowReward(false)}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontSize: 28, fontWeight: "900" },
  subtitle: { fontSize: 14, marginTop: 4 },
  content: { paddingHorizontal: 20, gap: 16 },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardTitle: { fontSize: 17, fontWeight: "700" },
  calBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  calBadgeText: { fontSize: 12, fontWeight: "700" },
  macroRings: { flexDirection: "row", justifyContent: "space-around", paddingVertical: 6 },
  hydrationHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  goalBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1 },
  goalBadgeText: { fontSize: 11, fontWeight: "700" },
  waterTracker: { flexDirection: "row", gap: 14, alignItems: "flex-start" },
  bottleContainer: { alignItems: "center", gap: 6 },
  bottle: {
    width: 44,
    height: 110,
    borderRadius: 10,
    borderWidth: 2,
    overflow: "hidden",
    justifyContent: "flex-end",
  },
  waterFill: { width: "100%", borderRadius: 8 },
  waterCount: { fontSize: 13, fontWeight: "800" },
  glassesGrid: { flex: 1, flexDirection: "row", flexWrap: "wrap", gap: 8 },
  glassBtn: { width: 46, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1.5, gap: 1 },
  glassNum: { fontSize: 9, fontWeight: "700" },
  formGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  formField: { width: "47%", gap: 6 },
  fieldLabel: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  fieldInput: { borderRadius: 12, borderWidth: 1.5, padding: 12, fontSize: 16, fontWeight: "700" },
  logBtn: { padding: 14, borderRadius: 14, alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 8 },
  logBtnText: { color: "white", fontWeight: "700", fontSize: 16 },
  sectionTitle: { fontSize: 20, fontWeight: "800" },
  plansScroll: { gap: 12, paddingBottom: 4 },
  planCard: { width: 140, borderRadius: 20, borderWidth: 1, padding: 14, gap: 6, alignItems: "center" },
  planEmoji: { fontSize: 32 },
  planTitle: { fontSize: 14, fontWeight: "700", textAlign: "center" },
  planSub: { fontSize: 11, textAlign: "center" },
  planCals: { fontSize: 13, fontWeight: "700" },
  mealDetail: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 12 },
  mealRow: { paddingLeft: 12, paddingVertical: 2 },
  mealTime: { fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  mealText: { fontSize: 14, marginTop: 2 },
  suppCard: { flexDirection: "row", alignItems: "center", gap: 14, borderRadius: 20, borderWidth: 1, padding: 16 },
  suppIconBg: { width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  suppEmoji: { fontSize: 28 },
  suppInfo: { flex: 1, gap: 4 },
  suppTitle: { fontSize: 15, fontWeight: "800" },
  suppSub: { fontSize: 12, lineHeight: 17 },
  suppTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, alignSelf: "flex-start", marginTop: 2 },
  suppTagText: { fontSize: 12, fontWeight: "800" },
});
