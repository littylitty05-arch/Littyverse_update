import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Animated,
  Platform,
  RefreshControl,
  Linking,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import ProgressRing from "@/components/ProgressRing";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { apiFetch } from "@/lib/api";

const LITTY_LINES = [
  "You built different.",
  "No off days.",
  "Champions don't skip.",
  "Today decides tomorrow.",
  "Pain is temporary. Results are forever.",
  "Get up. Show up. Lock in.",
  "The grind never lies.",
  "Make it count.",
  "No excuses. Just results.",
  "Build the strongest version of yourself.",
  "Every rep. Every night. Every meal. It adds up.",
  "This is not a fitness app. This is your life OS.",
];

const NON_NEGOTIABLES = [
  { id: "sleep", label: "Sleep", sub: "7–9 hours", icon: "moon-outline", color: "#818cf8" },
  { id: "hydration", label: "Hydration", sub: "Water target", icon: "water-outline", color: "#38bdf8" },
  { id: "movement", label: "Movement", sub: "Steps / activity", icon: "walk-outline", color: "#34d399" },
  { id: "training", label: "Training", sub: "Scheduled session", icon: "barbell-outline", color: "#a78bfa" },
  { id: "nutrition", label: "Nutrition", sub: "Clean meals", icon: "leaf-outline", color: "#4ade80" },
  { id: "focus", label: "Mental Reset", sub: "Focus block", icon: "infinite-outline", color: "#f59e0b" },
] as const;

type NonNegId = typeof NON_NEGOTIABLES[number]["id"];

function getLevelInfo(streak: number, totalWorkouts: number, totalLtk: number) {
  const xp = streak * 10 + totalWorkouts * 5 + Math.floor(totalLtk / 10);
  const thresholds = [
    { level: 50, xp: 5000, title: "Longevity Master" },
    { level: 20, xp: 1500, title: "Elite Performance" },
    { level: 10, xp: 500, title: "Optimized Human" },
    { level: 5, xp: 200, title: "Stable Routine" },
    { level: 1, xp: 0, title: "Base Activated" },
  ];
  const found = thresholds.find((t) => xp >= t.xp) ?? thresholds[thresholds.length - 1];
  const nextThreshold = thresholds[thresholds.indexOf(found) - 1];
  const progress = nextThreshold
    ? Math.min((xp - found.xp) / (nextThreshold.xp - found.xp), 1)
    : 1;
  return { level: found.level, title: found.title, xp, progress };
}

function getFlameColor(streak: number) {
  if (streak === 0) return "#4b5563";
  if (streak < 3) return "#f97316";
  if (streak < 7) return "#ef4444";
  if (streak < 14) return "#dc2626";
  return "#b91c1c";
}

export default function BaseBlueprint() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const todayKey = new Date().toISOString().split("T")[0];
  const [littyIdx, setLittyIdx] = useState(() => Math.floor(Math.random() * LITTY_LINES.length));
  const [checked, setChecked] = useState<Set<NonNegId>>(new Set());
  const [checkedIn, setCheckedIn] = useState(false);
  const [checkingIn, setCheckingIn] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const checkInAnim = useRef(new Animated.Value(1)).current;
  const flamePulse = useRef(new Animated.Value(1)).current;
  const cardAnims = useRef(
    Object.fromEntries(NON_NEGOTIABLES.map((n) => [n.id, new Animated.Value(1)]))
  ).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }).start();
    const interval = setInterval(() => setLittyIdx((i) => (i + 1) % LITTY_LINES.length), 4500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(`nn-${todayKey}`).then((raw) => {
      if (raw) {
        try { setChecked(new Set(JSON.parse(raw))); } catch {}
      }
    });
  }, [todayKey]);

  const toggleNonNeg = useCallback((id: NonNegId) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const anim = cardAnims[id];
    Animated.sequence([
      Animated.timing(anim, { toValue: 0.93, duration: 80, useNativeDriver: true }),
      Animated.spring(anim, { toValue: 1, friction: 4, useNativeDriver: true }),
    ]).start();
    setChecked((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      AsyncStorage.setItem(`nn-${todayKey}`, JSON.stringify([...next]));
      return next;
    });
  }, [todayKey, cardAnims]);

  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery({
    queryKey: ["littyfit-stats"],
    queryFn: async () => {
      const res = await apiFetch("/api/littyfit/stats");
      if (!res.ok) return null;
      const data = await res.json();
      if (data?.checkedInToday) setCheckedIn(true);
      return data;
    },
    enabled: !!user && !user.isDemo,
  });

  const { data: balance, refetch: refetchBalance } = useQuery({
    queryKey: ["ltk-balance", user?.id],
    queryFn: async () => {
      const res = await apiFetch(`/api/ltk/balance/${user?.id}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user?.id && !user.isDemo,
  });

  const handleCheckIn = async () => {
    if (checkedIn || checkingIn) return;
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setCheckingIn(true);
    Animated.sequence([
      Animated.timing(checkInAnim, { toValue: 0.92, duration: 100, useNativeDriver: true }),
      Animated.spring(checkInAnim, { toValue: 1, useNativeDriver: true }),
    ]).start();
    try {
      await apiFetch("/api/littyfit/checkin", { method: "POST", body: JSON.stringify({ date: todayKey }) });
      setCheckedIn(true);
      refetchStats();
      refetchBalance();
    } catch {
      setCheckedIn(true);
    }
    setCheckingIn(false);
  };

  const refresh = async () => { await Promise.all([refetchStats(), refetchBalance()]); };

  const streak = user?.isDemo ? 7 : (stats?.streak ?? 0);
  const totalWorkouts = user?.isDemo ? 14 : (stats?.totalWorkouts ?? 0);
  const totalLtk = user?.isDemo ? 350 : (stats?.totalLtk ?? 0);
  const ltkBalance = user?.isDemo ? 350 : (balance?.balance ?? 0);
  const isCheckedIn = user?.isDemo ? false : checkedIn;

  const completedCount = checked.size;
  const totalCount = NON_NEGOTIABLES.length;
  const completionPct = completedCount / totalCount;
  const allDone = completedCount === totalCount;

  const { level, title: levelTitle, progress: levelProgress } = getLevelInfo(streak, totalWorkouts, totalLtk);

  const energyScore = Math.min(100, Math.round(completionPct * 60 + streak * 2));
  const consistencyScore = Math.min(100, Math.round(streak * 3 + (totalWorkouts / 5) * 2));
  const recoveryScore = checked.has("sleep") ? 85 : 55;
  const sleepScore = checked.has("sleep") ? 90 : 60;
  const flameColor = getFlameColor(streak);

  const ringColor = allDone ? "#10b981" : completionPct >= 0.5 ? colors.purple : "#4b5563";

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPad + 90 }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={statsLoading} onRefresh={refresh} tintColor={colors.purpleLight} />
      }
    >
      <Animated.View style={{ opacity: fadeAnim }}>
        {/* Top bar */}
        <View style={[styles.topBar, { paddingTop: topPad + 16 }]}>
          <View style={styles.topLeft}>
            <Text style={[styles.appLabel, { color: colors.textMuted }]}>LittyFit</Text>
            <Text style={[styles.screenTitle, { color: colors.textPrimary }]}>Base Blueprint</Text>
          </View>
          <View style={styles.topRight}>
            <View style={[styles.ltkPill, { backgroundColor: "rgba(245,158,11,0.12)", borderColor: "rgba(245,158,11,0.3)" }]}>
              <AppIcon name="star" size={13} color={colors.amber} />
              <Text style={[styles.ltkText, { color: colors.amber }]}>{ltkBalance.toLocaleString()} LTK</Text>
            </View>
          </View>
        </View>

        {/* Level Badge */}
        <View style={[styles.levelCard, { backgroundColor: "rgba(124,58,237,0.1)", borderColor: "rgba(124,58,237,0.25)" }]}>
          <View style={styles.levelLeft}>
            <View style={[styles.levelBadge, { backgroundColor: colors.purple }]}>
              <Text style={styles.levelNum}>{level}</Text>
            </View>
            <View>
              <Text style={[styles.levelTitle, { color: colors.textPrimary }]}>{levelTitle}</Text>
              <Text style={[styles.levelSub, { color: colors.textMuted }]}>Human OS Level {level}</Text>
            </View>
          </View>
          <View style={styles.levelRight}>
            <View style={[styles.levelBarBg, { backgroundColor: colors.border }]}>
              <View style={[styles.levelBarFill, { width: `${Math.round(levelProgress * 100)}%`, backgroundColor: colors.purpleLight }]} />
            </View>
            <Text style={[styles.levelPct, { color: colors.textMuted }]}>{Math.round(levelProgress * 100)}%</Text>
          </View>
        </View>

        {/* Litty Mode */}
        <View style={[styles.littyBanner, { backgroundColor: "rgba(124,58,237,0.08)", borderColor: "rgba(124,58,237,0.2)" }]}>
          <View style={[styles.littyBadge, { backgroundColor: colors.purple }]}>
            <AppIcon name="flash" size={12} color="white" />
            <Text style={styles.littyBadgeText}>LITTY MODE</Text>
          </View>
          <Text style={[styles.littyQuote, { color: colors.purpleLight }]}>"{LITTY_LINES[littyIdx]}"</Text>
        </View>

        <View style={styles.content}>
          {/* Daily Non-Negotiables */}
          <View>
            <View style={styles.sectionHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Daily Non-Negotiables</Text>
                <Text style={[styles.sectionSub, { color: colors.textMuted }]}>
                  {completedCount}/{totalCount} complete
                </Text>
              </View>
              <ProgressRing
                progress={completionPct}
                size={64}
                strokeWidth={6}
                color={ringColor}
                trackColor="rgba(255,255,255,0.07)"
              >
                <Text style={{ color: allDone ? "#10b981" : colors.textPrimary, fontSize: 14, fontWeight: "900" }}>
                  {Math.round(completionPct * 100)}%
                </Text>
              </ProgressRing>
            </View>

            {/* Checklist Grid */}
            <View style={styles.nnGrid}>
              {NON_NEGOTIABLES.map((item) => {
                const done = checked.has(item.id);
                return (
                  <Animated.View key={item.id} style={{ transform: [{ scale: cardAnims[item.id] }], width: "47%" }}>
                    <Pressable
                      style={[
                        styles.nnCard,
                        {
                          backgroundColor: done ? `${item.color}18` : colors.card,
                          borderColor: done ? item.color : colors.border,
                        },
                      ]}
                      onPress={() => toggleNonNeg(item.id)}
                    >
                      <View style={[styles.nnIconCircle, { backgroundColor: done ? `${item.color}30` : colors.secondary }]}>
                        <AppIcon name={item.icon as any} size={18} color={done ? item.color : colors.textMuted} />
                      </View>
                      <Text style={[styles.nnLabel, { color: done ? colors.textPrimary : colors.textSecondary }]}>{item.label}</Text>
                      <Text style={[styles.nnSub, { color: colors.textMuted }]}>{item.sub}</Text>
                      <View style={[styles.nnCheck, { backgroundColor: done ? item.color : colors.border }]}>
                        {done && <AppIcon name="checkmark" size={10} color="white" />}
                      </View>
                    </Pressable>
                  </Animated.View>
                );
              })}
            </View>
            {allDone && (
              <View style={[styles.systemBadge, { backgroundColor: "rgba(16,185,129,0.15)", borderColor: colors.green }]}>
                <AppIcon name="checkmark-circle" size={14} color={colors.green} />
                <Text style={[styles.systemBadgeText, { color: colors.green }]}>System Complete — All 6 Non-Negotiables Done</Text>
              </View>
            )}
          </View>

          {/* Score Cards */}
          <View>
            <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Today's Scores</Text>
            <View style={styles.scoreGrid}>
              {[
                { label: "Energy", value: energyScore, color: colors.amber, icon: "flash-outline" },
                { label: "Recovery", value: recoveryScore, color: colors.green, icon: "heart-outline" },
                { label: "Sleep", value: sleepScore, color: "#818cf8", icon: "moon-outline" },
                { label: "Consistency", value: consistencyScore, color: colors.purpleLight, icon: "trending-up-outline" },
              ].map((s) => (
                <View key={s.label} style={[styles.scoreCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <AppIcon name={s.icon as any} size={16} color={s.color} />
                  <Text style={[styles.scoreValue, { color: colors.textPrimary }]}>
                    {statsLoading && !user?.isDemo ? "—" : s.value}
                  </Text>
                  <Text style={[styles.scoreLabel, { color: colors.textMuted }]}>{s.label}</Text>
                  <View style={[styles.scoreMini, { backgroundColor: colors.border }]}>
                    <View style={[styles.scoreMiniBar, { width: `${s.value}%`, backgroundColor: s.color }]} />
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Streak Check-In */}
          <Animated.View style={{ transform: [{ scale: checkInAnim }] }}>
            <View style={[
              styles.checkInCard,
              {
                backgroundColor: isCheckedIn ? "rgba(16,185,129,0.08)" : "rgba(124,58,237,0.08)",
                borderColor: isCheckedIn ? colors.green : colors.purple,
              },
            ]}>
              <View style={styles.checkInLeft}>
                <View style={styles.streakRow}>
                  <AppIcon name="flame" size={28} color={flameColor} />
                  <Text style={[styles.streakNum, { color: colors.textPrimary }]}>{streak}</Text>
                  <View>
                    <Text style={[styles.streakLabel, { color: colors.textMuted }]}>day streak</Text>
                    {streak >= 7 && (
                      <Text style={{ fontSize: 10, color: flameColor, fontWeight: "800" }}>
                        {streak >= 14 ? "🔥 ON FIRE" : "⚡ LOCKED IN"}
                      </Text>
                    )}
                  </View>
                </View>
                <Text style={[styles.checkInSub, { color: colors.textSecondary }]}>
                  {isCheckedIn ? "You're locked in. Keep the streak." : "Mark today as active."}
                </Text>
              </View>
              <Pressable
                style={[styles.checkInBtn, { backgroundColor: isCheckedIn ? colors.green : colors.purple }]}
                onPress={handleCheckIn}
                disabled={isCheckedIn || checkingIn}
              >
                <AppIcon name={isCheckedIn ? "checkmark-circle" : "checkmark"} size={18} color="white" />
                <Text style={styles.checkInBtnText}>{isCheckedIn ? "Locked In" : "Check In"}</Text>
              </Pressable>
            </View>
          </Animated.View>

          {/* Quick Train */}
          <View>
            <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Quick Train</Text>
            <Text style={[styles.sectionSub, { color: colors.textMuted }]}>No excuses. Pick your time.</Text>
            <View style={styles.quickRow}>
              {[
                { min: "10", label: "Flash", emoji: "⚡", color: "#818cf8" },
                { min: "20", label: "Burn", emoji: "🔥", color: colors.amber },
                { min: "45", label: "Beast", emoji: "💪", color: colors.purple },
              ].map((q) => (
                <Pressable
                  key={q.min}
                  style={[styles.quickCard, { backgroundColor: colors.card, borderColor: colors.border }]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    router.push({ pathname: "/quick-workout", params: { preset: q.min } });
                  }}
                >
                  <Text style={styles.quickEmoji}>{q.emoji}</Text>
                  <Text style={[styles.quickMin, { color: colors.textPrimary }]}>{q.min}</Text>
                  <Text style={[styles.quickUnit, { color: colors.textMuted }]}>min</Text>
                  <Text style={[styles.quickLabel, { color: q.color }]}>{q.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Go Deeper */}
          <View style={styles.goDeepRow}>
            <Pressable
              style={[styles.goDeepCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => router.push("/(tabs)/workouts")}
            >
              <View style={[styles.goDeepIcon, { backgroundColor: "rgba(167,139,250,0.15)" }]}>
                <AppIcon name="barbell" size={24} color={colors.purpleLight} />
              </View>
              <Text style={[styles.goDeepLabel, { color: colors.textPrimary }]}>Train</Text>
              <Text style={[styles.goDeepSub, { color: colors.textMuted }]}>10 programs</Text>
              <View style={[styles.ltkTag, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                <Text style={[styles.ltkTagText, { color: colors.amber }]}>+50 LTK</Text>
              </View>
            </Pressable>
            <Pressable
              style={[styles.goDeepCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => router.push("/(tabs)/nutrition")}
            >
              <View style={[styles.goDeepIcon, { backgroundColor: "rgba(74,222,128,0.12)" }]}>
                <AppIcon name="leaf" size={24} color="#4ade80" />
              </View>
              <Text style={[styles.goDeepLabel, { color: colors.textPrimary }]}>Fuel</Text>
              <Text style={[styles.goDeepSub, { color: colors.textMuted }]}>6 diet plans</Text>
              <View style={[styles.ltkTag, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                <Text style={[styles.ltkTagText, { color: colors.amber }]}>+10 LTK</Text>
              </View>
            </Pressable>
            <Pressable
              style={[styles.goDeepCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => router.push("/(tabs)/yoga")}
            >
              <View style={[styles.goDeepIcon, { backgroundColor: "rgba(129,140,248,0.12)" }]}>
                <AppIcon name="moon" size={24} color="#818cf8" />
              </View>
              <Text style={[styles.goDeepLabel, { color: colors.textPrimary }]}>Recover</Text>
              <Text style={[styles.goDeepSub, { color: colors.textMuted }]}>6 flows</Text>
              <View style={[styles.ltkTag, { backgroundColor: "rgba(245,158,11,0.1)" }]}>
                <Text style={[styles.ltkTagText, { color: colors.amber }]}>+25 LTK</Text>
              </View>
            </Pressable>
          </View>

          {user?.isDemo && (
            <Pressable
              style={[styles.signInNudge, { backgroundColor: colors.card, borderColor: colors.purple }]}
              onPress={() => router.push("/login")}
            >
              <AppIcon name="star" size={16} color={colors.purpleLight} />
              <Text style={[styles.signInNudgeText, { color: colors.textPrimary }]}>Sign in to earn real LTK tokens</Text>
              <AppIcon name="chevron-forward" size={16} color={colors.textMuted} />
            </Pressable>
          )}

          {/* Littyverse Footer */}
          <Pressable
            style={[styles.littyFooter, { backgroundColor: "rgba(124,58,237,0.07)", borderColor: "rgba(124,58,237,0.25)" }]}
            onPress={() => {
              if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              Linking.openURL("https://www.littyverse.com");
            }}
          >
            <View style={[styles.littyFooterDot, { backgroundColor: colors.purple }]} />
            <Text style={[styles.littyFooterText, { color: colors.textSecondary }]}>
              Part of the <Text style={{ color: colors.purpleLight, fontWeight: "800" }}>Littyverse</Text> ecosystem
            </Text>
            <Text style={[styles.littyFooterLink, { color: colors.purpleLight }]}>littyverse.com →</Text>
          </Pressable>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", paddingHorizontal: 20, paddingBottom: 10 },
  topLeft: {},
  topRight: {},
  appLabel: { fontSize: 11, textTransform: "uppercase", letterSpacing: 1.5, fontWeight: "700" },
  screenTitle: { fontSize: 26, fontWeight: "900" },
  ltkPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  ltkText: { fontSize: 14, fontWeight: "800" },
  levelCard: {
    marginHorizontal: 20, marginBottom: 10, padding: 16, borderRadius: 18, borderWidth: 1,
    flexDirection: "row", alignItems: "center", gap: 14,
  },
  levelLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  levelBadge: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  levelNum: { color: "white", fontSize: 20, fontWeight: "900" },
  levelTitle: { fontSize: 15, fontWeight: "800" },
  levelSub: { fontSize: 11, marginTop: 2 },
  levelRight: { alignItems: "flex-end", gap: 4 },
  levelBarBg: { width: 80, height: 6, borderRadius: 3, overflow: "hidden" },
  levelBarFill: { height: "100%", borderRadius: 3 },
  levelPct: { fontSize: 11 },
  littyBanner: { marginHorizontal: 20, marginBottom: 6, borderRadius: 16, borderWidth: 1, padding: 14, gap: 8 },
  littyBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, alignSelf: "flex-start" },
  littyBadgeText: { color: "white", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  littyQuote: { fontSize: 15, fontWeight: "700", fontStyle: "italic" },
  content: { paddingHorizontal: 20, gap: 22, paddingTop: 12 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  sectionTitle: { fontSize: 18, fontWeight: "900" },
  sectionSub: { fontSize: 12, marginTop: 2 },
  systemBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14, borderWidth: 1, marginTop: 12 },
  systemBadgeText: { fontSize: 12, fontWeight: "700", flex: 1 },
  nnGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  nnCard: { padding: 14, borderRadius: 18, borderWidth: 1.5, gap: 6 },
  nnIconCircle: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  nnLabel: { fontSize: 13, fontWeight: "700" },
  nnSub: { fontSize: 11 },
  nnCheck: { position: "absolute", top: 10, right: 10, width: 18, height: 18, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  scoreGrid: { flexDirection: "row", gap: 10, marginTop: 12 },
  scoreCard: { flex: 1, alignItems: "center", padding: 12, borderRadius: 16, borderWidth: 1, gap: 4 },
  scoreValue: { fontSize: 22, fontWeight: "900" },
  scoreLabel: { fontSize: 10, textTransform: "uppercase", letterSpacing: 0.5 },
  scoreMini: { width: "100%", height: 3, borderRadius: 2, overflow: "hidden", marginTop: 4 },
  scoreMiniBar: { height: "100%", borderRadius: 2 },
  checkInCard: { borderRadius: 20, borderWidth: 2, padding: 18, flexDirection: "row", alignItems: "center", gap: 14 },
  checkInLeft: { flex: 1, gap: 5 },
  streakRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  streakNum: { fontSize: 32, fontWeight: "900" },
  streakLabel: { fontSize: 13 },
  checkInSub: { fontSize: 12 },
  checkInBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 11, borderRadius: 14 },
  checkInBtnText: { color: "white", fontWeight: "800", fontSize: 13 },
  quickRow: { flexDirection: "row", gap: 12, marginTop: 10 },
  quickCard: { flex: 1, borderRadius: 20, borderWidth: 1, padding: 14, alignItems: "center", gap: 2 },
  quickEmoji: { fontSize: 26, marginBottom: 4 },
  quickMin: { fontSize: 26, fontWeight: "900" },
  quickUnit: { fontSize: 11 },
  quickLabel: { fontSize: 12, fontWeight: "800" },
  goDeepRow: { flexDirection: "row", gap: 10 },
  goDeepCard: { flex: 1, borderRadius: 20, borderWidth: 1, padding: 14, alignItems: "center", gap: 6 },
  goDeepIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  goDeepLabel: { fontSize: 14, fontWeight: "700" },
  goDeepSub: { fontSize: 11 },
  ltkTag: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  ltkTagText: { fontSize: 11, fontWeight: "800" },
  signInNudge: { flexDirection: "row", alignItems: "center", gap: 10, padding: 16, borderRadius: 16, borderWidth: 1 },
  signInNudgeText: { flex: 1, fontSize: 14, fontWeight: "600" },
  littyFooter: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 14, borderWidth: 1 },
  littyFooterDot: { width: 8, height: 8, borderRadius: 4 },
  littyFooterText: { flex: 1, fontSize: 13 },
  littyFooterLink: { fontSize: 13, fontWeight: "700" },
});
