import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  SafeAreaView,
} from "react-native";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useColors } from "@/hooks/useColors";

const QUICK_WORKOUTS: Record<string, Record<string, any[]>> = {
  "10": {
    home: [
      { name: "Jumping Jacks", sets: 2, reps: "30 sec", duration: 30, instructions: "Full range of motion. Get the heart going." },
      { name: "Push-ups", sets: 2, reps: "10", duration: 40, instructions: "Chest to floor. No half reps." },
      { name: "Bodyweight Squats", sets: 2, reps: "15", duration: 40, instructions: "Deep squat, drive through heels." },
      { name: "Plank", sets: 2, reps: "30 sec", duration: 30, instructions: "Tight core. No sagging hips." },
      { name: "High Knees", sets: 2, reps: "20 sec", duration: 20, instructions: "Drive knees up, pump your arms." },
    ],
    gym: [
      { name: "Treadmill Sprint", sets: 1, reps: "2 min", duration: 120, instructions: "Push yourself. Max effort." },
      { name: "Dumbbell Squat", sets: 3, reps: "12", duration: 40, instructions: "Dumbbells at shoulders, squat deep." },
      { name: "Cable Row", sets: 3, reps: "10", duration: 40, instructions: "Pull elbows back, squeeze." },
      { name: "Lat Pulldown", sets: 2, reps: "10", duration: 40, instructions: "Pull to chest, control the return." },
    ],
  },
  "20": {
    home: [
      { name: "Warm-up Jog in Place", sets: 1, reps: "60 sec", duration: 60, instructions: "Easy pace, just warm up." },
      { name: "Burpees", sets: 3, reps: "8", duration: 45, instructions: "Full range — jump up, plank down." },
      { name: "Push-ups", sets: 3, reps: "12", duration: 40, instructions: "Chest touches floor every rep." },
      { name: "Jump Squats", sets: 3, reps: "10", duration: 40, instructions: "Squat low, explode up." },
      { name: "Mountain Climbers", sets: 3, reps: "20 sec", duration: 20, instructions: "Keep hips level. Fast feet." },
      { name: "Tricep Dips", sets: 3, reps: "12", duration: 40, instructions: "Use a chair. Full dip." },
      { name: "Plank Hold", sets: 2, reps: "45 sec", duration: 45, instructions: "No dropping. Hold it." },
    ],
    gym: [
      { name: "Barbell Squat", sets: 4, reps: "8", duration: 50, instructions: "Go below parallel. Control it." },
      { name: "Bench Press", sets: 4, reps: "8", duration: 50, instructions: "Bar to chest, drive up." },
      { name: "Bent Over Row", sets: 3, reps: "10", duration: 45, instructions: "Hinge at hip, row to hip." },
      { name: "Shoulder Press", sets: 3, reps: "10", duration: 45, instructions: "Press overhead, lock out at top." },
      { name: "Romanian Deadlift", sets: 3, reps: "10", duration: 45, instructions: "Hinge at hips, feel the hamstrings." },
    ],
  },
  "45": {
    home: [
      { name: "Warm-up Circuit", sets: 2, reps: "60 sec", duration: 60, instructions: "Jog, arm circles, hip circles." },
      { name: "Push-up Pyramid", sets: 5, reps: "5-10-15-10-5", duration: 60, instructions: "Rest 30 sec between sets." },
      { name: "Squat Variations", sets: 4, reps: "15 each", duration: 50, instructions: "Regular, wide, narrow, jump." },
      { name: "Core Circuit", sets: 3, reps: "45 sec each", duration: 45, instructions: "Plank, side plank, dead bug." },
      { name: "Plyometric Lunges", sets: 3, reps: "10 each", duration: 40, instructions: "Jump switch lunges. Stay low." },
      { name: "Pike Push-ups", sets: 3, reps: "12", duration: 40, instructions: "Inverted V — targets shoulders." },
      { name: "Burpee to Tuck Jump", sets: 3, reps: "8", duration: 50, instructions: "Finish every rep strong." },
      { name: "Cool Down Stretch", sets: 1, reps: "5 min", duration: 300, instructions: "Hold each stretch 30 seconds." },
    ],
    gym: [
      { name: "Squat", sets: 5, reps: "5", duration: 60, instructions: "Heavy. Compound movement first." },
      { name: "Deadlift", sets: 4, reps: "5", duration: 60, instructions: "Pull the floor away from you." },
      { name: "Bench Press", sets: 4, reps: "8", duration: 50, instructions: "Full range. Touch chest." },
      { name: "Pull-ups or Lat Pulldown", sets: 4, reps: "8", duration: 50, instructions: "Full hang to chin over bar." },
      { name: "Overhead Press", sets: 3, reps: "10", duration: 45, instructions: "Lock out overhead." },
      { name: "Dumbbell Curl to Press", sets: 3, reps: "12", duration: 45, instructions: "Curl up, then press overhead." },
      { name: "Cable Fly", sets: 3, reps: "12", duration: 40, instructions: "Feel the stretch, squeeze at peak." },
      { name: "Abs Circuit", sets: 3, reps: "60 sec", duration: 60, instructions: "Plank, crunches, leg raises." },
    ],
  },
};

const LITTY_LINES = [
  "No excuses. Just results.",
  "You built different.",
  "Champions don't skip.",
  "Pain is temporary. Results are forever.",
  "Today decides tomorrow.",
  "No off days.",
  "Make it count.",
  "The grind is the reward.",
];

export default function QuickWorkoutScreen() {
  const colors = useColors();
  const [duration, setDuration] = useState<"10" | "20" | "45" | null>(null);
  const [location, setLocation] = useState<"home" | "gym" | null>(null);
  const [motivation] = useState(() => LITTY_LINES[Math.floor(Math.random() * LITTY_LINES.length)]);

  const canStart = duration && location;
  const exercises = canStart ? QUICK_WORKOUTS[duration][location] : [];

  const handleStart = () => {
    if (!canStart) return;
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    router.push({
      pathname: "/workout-session",
      params: {
        programId: `quick-${duration}-${location}`,
        day: "1",
        exercisesJson: JSON.stringify(exercises),
        isQuick: "true",
      },
    });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable
          style={[styles.closeBtn, { backgroundColor: colors.card }]}
          onPress={() => router.back()}
        >
          <AppIcon name="close" size={22} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.headerText}>
          <Text style={[styles.title, { color: colors.textPrimary }]}>Quick Workout</Text>
          <Text style={[styles.sub, { color: colors.textMuted }]}>No excuses mode</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Litty Mode Quote */}
        <View style={[styles.littyCard, { backgroundColor: "rgba(124,58,237,0.15)", borderColor: colors.purple }]}>
          <AppIcon name="flash" size={20} color={colors.purpleLight} />
          <Text style={[styles.littyLine, { color: colors.purpleLight }]}>{motivation}</Text>
        </View>

        {/* Duration */}
        <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>How long?</Text>
        <View style={styles.optionRow}>
          {(["10", "20", "45"] as const).map((d) => (
            <Pressable
              key={d}
              style={[
                styles.optionCard,
                {
                  backgroundColor: duration === d ? colors.purple : colors.card,
                  borderColor: duration === d ? colors.purpleLight : colors.border,
                },
              ]}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setDuration(d);
              }}
            >
              <Text style={[styles.optionNum, { color: duration === d ? "white" : colors.textPrimary }]}>
                {d}
              </Text>
              <Text style={[styles.optionUnit, { color: duration === d ? "rgba(255,255,255,0.7)" : colors.textMuted }]}>
                min
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Location */}
        <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Where are you?</Text>
        <View style={styles.locationRow}>
          {([
            { id: "home", label: "Home", icon: "home-outline", sub: "No equipment" },
            { id: "gym", label: "Gym", icon: "fitness-outline", sub: "Full equipment" },
          ] as const).map((loc) => (
            <Pressable
              key={loc.id}
              style={[
                styles.locationCard,
                {
                  backgroundColor: location === loc.id ? colors.purple : colors.card,
                  borderColor: location === loc.id ? colors.purpleLight : colors.border,
                },
              ]}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setLocation(loc.id);
              }}
            >
              <AppIcon
                name={loc.icon}
                size={28}
                color={location === loc.id ? "white" : colors.purpleLight}
              />
              <Text style={[styles.locationLabel, { color: location === loc.id ? "white" : colors.textPrimary }]}>
                {loc.label}
              </Text>
              <Text style={[styles.locationSub, { color: location === loc.id ? "rgba(255,255,255,0.7)" : colors.textMuted }]}>
                {loc.sub}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Preview */}
        {canStart && (
          <View style={[styles.previewCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.previewTitle, { color: colors.textPrimary }]}>
              {duration} min {location === "home" ? "Home" : "Gym"} Workout
            </Text>
            <Text style={[styles.previewCount, { color: colors.textMuted }]}>
              {exercises.length} exercises
            </Text>
            <View style={styles.exerciseList}>
              {exercises.map((ex, i) => (
                <View key={i} style={styles.exerciseRow}>
                  <View style={[styles.exNum, { backgroundColor: colors.secondary }]}>
                    <Text style={[styles.exNumText, { color: colors.purpleLight }]}>{i + 1}</Text>
                  </View>
                  <View style={styles.exInfo}>
                    <Text style={[styles.exName, { color: colors.textPrimary }]}>{ex.name}</Text>
                    <Text style={[styles.exMeta, { color: colors.textMuted }]}>
                      {ex.sets} × {ex.reps}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Start Button */}
        <Pressable
          style={[
            styles.startBtn,
            { backgroundColor: canStart ? colors.purple : colors.muted },
          ]}
          onPress={handleStart}
          disabled={!canStart}
        >
          <AppIcon name="flash" size={22} color="white" />
          <Text style={styles.startBtnText}>
            {canStart ? `Start ${duration} Min Workout` : "Pick duration & location"}
          </Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingVertical: 16, gap: 14 },
  closeBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  headerText: { flex: 1 },
  title: { fontSize: 22, fontWeight: "900" },
  sub: { fontSize: 13 },
  content: { paddingHorizontal: 20, paddingBottom: 40, gap: 20 },
  littyCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  littyLine: { fontSize: 15, fontWeight: "700", fontStyle: "italic", flex: 1 },
  sectionLabel: { fontSize: 13, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1 },
  optionRow: { flexDirection: "row", gap: 12 },
  optionCard: {
    flex: 1,
    borderRadius: 20,
    borderWidth: 1.5,
    alignItems: "center",
    paddingVertical: 20,
    gap: 4,
  },
  optionNum: { fontSize: 36, fontWeight: "900" },
  optionUnit: { fontSize: 13, fontWeight: "600" },
  locationRow: { flexDirection: "row", gap: 14 },
  locationCard: {
    flex: 1,
    borderRadius: 20,
    borderWidth: 1.5,
    alignItems: "center",
    paddingVertical: 20,
    gap: 8,
  },
  locationLabel: { fontSize: 16, fontWeight: "800" },
  locationSub: { fontSize: 12 },
  previewCard: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 12 },
  previewTitle: { fontSize: 17, fontWeight: "800" },
  previewCount: { fontSize: 13, marginTop: -8 },
  exerciseList: { gap: 10 },
  exerciseRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  exNum: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  exNumText: { fontSize: 13, fontWeight: "800" },
  exInfo: { flex: 1 },
  exName: { fontSize: 14, fontWeight: "600" },
  exMeta: { fontSize: 12 },
  startBtn: {
    height: 60,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginTop: 4,
  },
  startBtnText: { color: "white", fontSize: 17, fontWeight: "800" },
});
