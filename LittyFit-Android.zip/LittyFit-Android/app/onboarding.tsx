import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  ActivityIndicator,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useColors } from "@/hooks/useColors";
import { apiFetch } from "@/lib/api";

const STEPS = [
  {
    id: "goal",
    title: "What's your goal?",
    subtitle: "We'll personalize your experience",
    options: [
      { id: "lose-weight", label: "Lose Weight", icon: "flame-outline" },
      { id: "build-muscle", label: "Build Muscle", icon: "barbell-outline" },
      { id: "improve-energy", label: "Improve Energy", icon: "flash-outline" },
      { id: "get-consistent", label: "Get Consistent", icon: "calendar-outline" },
      { id: "just-move", label: "Just Move More", icon: "walk-outline" },
    ],
  },
  {
    id: "level",
    title: "Your fitness level?",
    subtitle: "Be honest — we won't judge",
    options: [
      { id: "beginner", label: "Beginner", icon: "leaf-outline" },
      { id: "intermediate", label: "Intermediate", icon: "trending-up-outline" },
      { id: "advanced", label: "Advanced", icon: "trophy-outline" },
    ],
  },
  {
    id: "preference",
    title: "Where do you work out?",
    subtitle: "Pick your training environment",
    options: [
      { id: "home", label: "Home", icon: "home-outline" },
      { id: "gym", label: "Gym", icon: "fitness-outline" },
      { id: "bodyweight", label: "Bodyweight Only", icon: "body-outline" },
      { id: "mixed", label: "Mixed", icon: "shuffle-outline" },
    ],
  },
  {
    id: "interests",
    title: "What interests you?",
    subtitle: "Select all that apply",
    multi: true,
    options: [
      { id: "yoga", label: "Yoga", icon: "flower-outline" },
      { id: "stretching", label: "Stretching", icon: "resize-outline" },
      { id: "nutrition", label: "Nutrition", icon: "nutrition-outline" },
      { id: "cardio", label: "Cardio", icon: "heart-outline" },
      { id: "strength", label: "Strength", icon: "barbell-outline" },
      { id: "recovery", label: "Recovery", icon: "bed-outline" },
    ],
  },
  {
    id: "minutes",
    title: "Daily workout time?",
    subtitle: "How long can you commit?",
    options: [
      { id: "15", label: "15 min", icon: "time-outline" },
      { id: "20", label: "20 min", icon: "time-outline" },
      { id: "30", label: "30 min", icon: "time-outline" },
      { id: "45", label: "45 min", icon: "time-outline" },
      { id: "60", label: "60 min", icon: "time-outline" },
    ],
  },
];

export default function OnboardingScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState(0);
  const [selections, setSelections] = useState<Record<string, string | string[]>>({});
  const [loading, setLoading] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const current = STEPS[step];
  const isMulti = !!(current as any).multi;

  const toggle = (optionId: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    if (isMulti) {
      const existing = (selections[current.id] as string[]) ?? [];
      if (existing.includes(optionId)) {
        setSelections({ ...selections, [current.id]: existing.filter((x) => x !== optionId) });
      } else {
        setSelections({ ...selections, [current.id]: [...existing, optionId] });
      }
    } else {
      setSelections({ ...selections, [current.id]: optionId });
    }
  };

  const isSelected = (optionId: string) => {
    const val = selections[current.id];
    if (isMulti) return ((val as string[]) ?? []).includes(optionId);
    return val === optionId;
  };

  const canAdvance = () => {
    const val = selections[current.id];
    if (!val) return false;
    if (isMulti) return ((val as string[]) ?? []).length > 0;
    return !!val;
  };

  const advance = async () => {
    if (!canAdvance()) return;
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    if (step < STEPS.length - 1) {
      setStep(step + 1);
    } else {
      setLoading(true);
      try {
        const interests = selections.interests as string[] ?? [];
        const dailyMinutes = parseInt(selections.minutes as string ?? "30");
        await apiFetch("/api/littyfit/profile", {
          method: "POST",
          body: JSON.stringify({
            goal: selections.goal,
            level: selections.level,
            preference: selections.preference,
            interests,
            dailyMinutes,
          }),
        });
        if (Platform.OS !== "web") {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }
        router.replace("/(tabs)");
      } catch {
        router.replace("/(tabs)");
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.top, { paddingTop: topPad + 20 }]}>
        {/* Progress dots */}
        <View style={styles.dotsRow}>
          {STEPS.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                {
                  backgroundColor: i <= step ? colors.purple : colors.muted,
                  width: i === step ? 24 : 8,
                },
              ]}
            />
          ))}
        </View>

        <Text style={[styles.stepCounter, { color: colors.textMuted }]}>
          Step {step + 1} of {STEPS.length}
        </Text>
        <Text style={[styles.title, { color: colors.textPrimary }]}>
          {current.title}
        </Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          {current.subtitle}
        </Text>
      </View>

      <ScrollView
        style={styles.scrollArea}
        contentContainerStyle={styles.optionsContainer}
        showsVerticalScrollIndicator={false}
      >
        {current.options.map((opt) => {
          const selected = isSelected(opt.id);
          return (
            <Pressable
              key={opt.id}
              style={[
                styles.option,
                {
                  backgroundColor: selected ? colors.purple : colors.card,
                  borderColor: selected ? colors.purpleLight : colors.border,
                },
              ]}
              onPress={() => toggle(opt.id)}
            >
              <View style={[styles.optionIcon, { backgroundColor: selected ? "rgba(255,255,255,0.2)" : colors.secondary }]}>
                <AppIcon
                  name={opt.icon as any}
                  size={22}
                  color={selected ? "white" : colors.purpleLight}
                />
              </View>
              <Text style={[styles.optionLabel, { color: selected ? "white" : colors.textPrimary }]}>
                {opt.label}
              </Text>
              {selected && isMulti && (
                <AppIcon name="checkmark-circle" size={20} color="white" />
              )}
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={[styles.bottomArea, { paddingBottom: bottomPad + 20 }]}>
        {step > 0 && (
          <Pressable
            style={[styles.backBtn, { borderColor: colors.border }]}
            onPress={() => setStep(step - 1)}
          >
            <AppIcon name="chevron-back" size={22} color={colors.textPrimary} />
          </Pressable>
        )}
        <Pressable
          style={[
            styles.nextBtn,
            { backgroundColor: canAdvance() ? colors.purple : colors.muted, flex: 1 },
          ]}
          onPress={advance}
          disabled={!canAdvance() || loading}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.nextText}>
              {step === STEPS.length - 1 ? "Get Started" : "Continue"}
            </Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  top: { paddingHorizontal: 24, paddingBottom: 16 },
  dotsRow: { flexDirection: "row", gap: 6, marginBottom: 16 },
  dot: { height: 8, borderRadius: 4 },
  stepCounter: { fontSize: 12, fontWeight: "600", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 },
  title: { fontSize: 28, fontWeight: "900", marginBottom: 6 },
  subtitle: { fontSize: 15 },
  scrollArea: { flex: 1, paddingHorizontal: 24 },
  optionsContainer: { gap: 12, paddingTop: 8, paddingBottom: 16 },
  option: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
  },
  optionIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  optionLabel: { fontSize: 16, fontWeight: "600", flex: 1 },
  bottomArea: { flexDirection: "row", gap: 12, paddingHorizontal: 24, paddingTop: 16 },
  backBtn: {
    width: 52,
    height: 56,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  nextBtn: { height: 56, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  nextText: { color: "white", fontSize: 17, fontWeight: "700" },
});
