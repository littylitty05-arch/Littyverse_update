import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Platform,
  Animated,
  SafeAreaView,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";
import AppIcon from "@/components/AppIcon";
import { useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { apiFetch } from "@/lib/api";
import { YOGA_FLOWS } from "@/data/littyfit";
import LTKRewardModal from "@/components/LTKRewardModal";

export default function YogaSession() {
  const colors = useColors();
  const params = useLocalSearchParams<{ flowId: string }>();
  const qc = useQueryClient();

  const flow = YOGA_FLOWS.find((f) => f.id === params.flowId);
  const poses = flow?.poses ?? [];

  const [currentPoseIdx, setCurrentPoseIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [showReward, setShowReward] = useState(false);
  const [isDone, setIsDone] = useState(false);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const elapsedRef = useRef(0);

  const currentPose = poses[currentPoseIdx];

  useEffect(() => {
    if (currentPose) {
      setTimeLeft(currentPose.duration);
      Animated.timing(progressAnim, {
        toValue: currentPoseIdx / poses.length,
        duration: 400,
        useNativeDriver: false,
      }).start();
    }
  }, [currentPoseIdx]);

  useEffect(() => {
    const interval = setInterval(() => {
      elapsedRef.current++;
      setElapsed(elapsedRef.current);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isDone) return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          advancePose();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [currentPoseIdx, isDone]);

  const advancePose = useCallback(() => {
    const next = currentPoseIdx + 1;
    if (next >= poses.length) {
      setIsDone(true);
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      completeFlow();
    } else {
      setCurrentPoseIdx(next);
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, [currentPoseIdx, poses.length]);

  const completeFlow = async () => {
    try {
      await apiFetch("/api/littyfit/yoga/complete", {
        method: "POST",
        body: JSON.stringify({ flowId: params.flowId, durationSeconds: elapsedRef.current }),
      });
      qc.invalidateQueries({ queryKey: ["littyfit-stats"] });
      qc.invalidateQueries({ queryKey: ["ltk-balance"] });
      qc.invalidateQueries({ queryKey: ["ltk-history"] });
    } catch {}
    setShowReward(true);
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  if (!flow) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <Text style={[styles.errorText, { color: colors.textSecondary }]}>Flow not found</Text>
        <Pressable onPress={() => router.back()} style={[styles.backBtnSm, { backgroundColor: colors.amber }]}>
          <Text style={{ color: "white", fontWeight: "700" }}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={styles.topBar}>
        <Pressable onPress={() => router.back()} style={[styles.closeBtn, { backgroundColor: colors.card }]}>
          <AppIcon name="close" size={22} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.topInfo}>
          <Text style={[styles.flowLabel, { color: colors.textMuted }]}>{flow.emoji} {flow.title}</Text>
          <Text style={[styles.poseCounter, { color: colors.textSecondary }]}>
            Pose {currentPoseIdx + 1} of {poses.length}
          </Text>
        </View>
        <Text style={[styles.elapsedTime, { color: colors.textMuted }]}>{formatTime(elapsed)}</Text>
      </View>

      {/* Progress */}
      <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
        <Animated.View style={[styles.progressFill, { width: progressWidth, backgroundColor: colors.amber }]} />
      </View>

      <View style={styles.content}>
        {!isDone ? (
          <>
            {/* Pose Icon */}
            <View style={[styles.poseIconContainer, { backgroundColor: "rgba(245,158,11,0.1)", borderColor: "rgba(245,158,11,0.3)" }]}>
              <AppIcon name="flower" size={48} color={colors.amber} />
            </View>

            {/* Pose Name */}
            <Text style={[styles.poseName, { color: colors.textPrimary }]}>
              {currentPose?.name ?? ""}
            </Text>

            {/* Timer */}
            <View style={[styles.timerCircle, { borderColor: colors.amber, backgroundColor: colors.card }]}>
              <Text style={[styles.timerText, { color: colors.amber }]}>{timeLeft}</Text>
              <Text style={[styles.timerSub, { color: colors.textMuted }]}>sec</Text>
            </View>

            {/* Instructions */}
            <Text style={[styles.instructions, { color: colors.textSecondary }]}>
              {currentPose?.instructions ?? ""}
            </Text>

            {/* Breath Cue */}
            <View style={[styles.breathCue, { backgroundColor: "rgba(124,58,237,0.1)", borderColor: "rgba(124,58,237,0.3)" }]}>
              <AppIcon name="leaf-outline" size={16} color={colors.purpleLight} />
              <Text style={[styles.breathText, { color: colors.purpleLight }]}>
                {currentPose?.breathCue ?? ""}
              </Text>
            </View>

            {/* Controls */}
            <View style={styles.controls}>
              <Pressable
                style={[styles.skipBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  advancePose();
                }}
              >
                <Text style={[styles.skipText, { color: colors.textSecondary }]}>Skip</Text>
              </Pressable>
              <Pressable
                style={[styles.nextBtn, { backgroundColor: colors.amber }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  advancePose();
                }}
              >
                <Text style={styles.nextBtnText}>
                  {currentPoseIdx === poses.length - 1 ? "Finish" : "Next Pose"}
                </Text>
                <AppIcon name="arrow-forward" size={18} color="white" />
              </Pressable>
            </View>
          </>
        ) : (
          <View style={styles.doneContent}>
            <AppIcon name="flower" size={72} color={colors.amber} />
            <Text style={[styles.doneTitle, { color: colors.textPrimary }]}>Flow Complete!</Text>
            <Text style={[styles.doneSub, { color: colors.textSecondary }]}>
              {formatTime(elapsed)} of mindful movement
            </Text>
          </View>
        )}
      </View>

      <LTKRewardModal
        visible={showReward}
        ltkAmount={25}
        title="Namaste!"
        message="You completed the flow. Your mind and body thank you."
        onClose={() => {
          setShowReward(false);
          router.back();
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  closeBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  topInfo: { flex: 1 },
  flowLabel: { fontSize: 12, fontWeight: "600" },
  poseCounter: { fontSize: 14, fontWeight: "600" },
  elapsedTime: { fontSize: 16, fontWeight: "700", fontVariant: ["tabular-nums"] },
  progressBg: { height: 4, marginHorizontal: 16, borderRadius: 2 },
  progressFill: { height: "100%", borderRadius: 2 },
  content: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 24, gap: 20 },
  poseIconContainer: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center", borderWidth: 2 },
  poseName: { fontSize: 30, fontWeight: "900", textAlign: "center" },
  timerCircle: { width: 150, height: 150, borderRadius: 75, borderWidth: 4, alignItems: "center", justifyContent: "center" },
  timerText: { fontSize: 56, fontWeight: "900", fontVariant: ["tabular-nums"] },
  timerSub: { fontSize: 14, fontWeight: "600" },
  instructions: { fontSize: 15, textAlign: "center", lineHeight: 24, paddingHorizontal: 16 },
  breathCue: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 16, borderWidth: 1 },
  breathText: { fontSize: 14, fontStyle: "italic", flex: 1, textAlign: "center" },
  controls: { flexDirection: "row", gap: 14, marginTop: 8 },
  skipBtn: { paddingHorizontal: 20, paddingVertical: 14, borderRadius: 14, borderWidth: 1 },
  skipText: { fontSize: 15, fontWeight: "600" },
  nextBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 14 },
  nextBtnText: { color: "white", fontSize: 16, fontWeight: "700" },
  doneContent: { alignItems: "center", gap: 16 },
  doneTitle: { fontSize: 32, fontWeight: "900" },
  doneSub: { fontSize: 16 },
  errorText: { fontSize: 18, marginBottom: 20 },
  backBtnSm: { paddingHorizontal: 24, paddingVertical: 14, borderRadius: 14 },
});
