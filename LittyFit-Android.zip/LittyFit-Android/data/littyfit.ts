export const LITTY_QUOTES = [
  "Earn while you burn.",
  "Every rep puts LTK in your wallet.",
  "Littyverse fuels your hustle.",
  "Train hard. Earn real.",
  "Your fitness is your currency.",
  "Move more. Earn more. Live Litty.",
  "Sweat is just fat crying — and LTK celebrating.",
  "Progress is profit.",
  "You don't stop when you're tired. You stop when you're done.",
  "The grind never stops. Neither does the LTK.",
  "Champions earn. Legends earn more.",
  "Your body is your biggest investment.",
  "One more rep. One more LTK.",
  "Pain is temporary. LTK is permanent.",
  "Litty life means active life.",
];

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  duration?: number;
  instructions: string;
}

export interface WorkoutDay {
  day: number;
  name: string;
  exercises: Exercise[];
}

export interface WorkoutProgram {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  level: "beginner" | "intermediate" | "advanced";
  daysPerWeek: number;
  weeks: number;
  ltkReward: number;
  days: WorkoutDay[];
}

export const WORKOUT_PROGRAMS: WorkoutProgram[] = [
  {
    id: "beginner-reset",
    emoji: "🌱",
    title: "Beginner Reset",
    subtitle: "Start fresh, build consistency",
    level: "beginner",
    daysPerWeek: 3,
    weeks: 4,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Full Body Basics",
        exercises: [
          { name: "Bodyweight Squats", sets: 3, reps: "12", instructions: "Stand feet shoulder-width apart, lower until thighs parallel." },
          { name: "Push-ups", sets: 3, reps: "8-10", instructions: "Keep core tight, lower chest to ground, push up." },
          { name: "Plank", sets: 3, reps: "20 sec", duration: 20, instructions: "Hold straight line from head to heels." },
          { name: "Glute Bridges", sets: 3, reps: "12", instructions: "Lie on back, drive hips up, squeeze glutes at top." },
        ],
      },
      {
        day: 2,
        name: "Core & Cardio",
        exercises: [
          { name: "Jumping Jacks", sets: 3, reps: "30 sec", duration: 30, instructions: "Full range of motion, controlled pace." },
          { name: "Crunches", sets: 3, reps: "15", instructions: "Hands behind head, curl upper body toward knees." },
          { name: "Mountain Climbers", sets: 3, reps: "20 sec", duration: 20, instructions: "Keep hips level, alternate knees to chest." },
          { name: "Dead Bug", sets: 3, reps: "10 each side", instructions: "Lower arm and opposite leg while keeping back flat." },
        ],
      },
      {
        day: 3,
        name: "Lower Body",
        exercises: [
          { name: "Lunges", sets: 3, reps: "10 each leg", instructions: "Step forward, lower back knee toward floor." },
          { name: "Wall Sit", sets: 3, reps: "30 sec", duration: 30, instructions: "Back flat against wall, thighs parallel." },
          { name: "Calf Raises", sets: 3, reps: "20", instructions: "Rise onto toes, hold 1 second, lower slowly." },
          { name: "Hip Circles", sets: 2, reps: "10 each side", instructions: "Slow controlled circles, full range of motion." },
        ],
      },
    ],
  },
  {
    id: "shred-mode",
    emoji: "🔥",
    title: "Shred Mode",
    subtitle: "High intensity fat burning",
    level: "intermediate",
    daysPerWeek: 4,
    weeks: 6,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "HIIT Blast",
        exercises: [
          { name: "Burpees", sets: 4, reps: "10", instructions: "Jump up, land in plank, push-up, jump back up." },
          { name: "High Knees", sets: 4, reps: "30 sec", duration: 30, instructions: "Drive knees to chest alternately, pump arms." },
          { name: "Jump Squats", sets: 4, reps: "12", instructions: "Squat down, explode up into a jump." },
          { name: "Speed Skaters", sets: 3, reps: "20 sec", duration: 20, instructions: "Leap side to side, touch down hand." },
        ],
      },
      {
        day: 2,
        name: "Upper Body Burn",
        exercises: [
          { name: "Diamond Push-ups", sets: 4, reps: "10", instructions: "Hands close together, targeting triceps." },
          { name: "Pike Push-ups", sets: 3, reps: "8", instructions: "Inverted V position, lower head toward floor." },
          { name: "Plank to Push-up", sets: 3, reps: "8 each side", instructions: "Alternate forearm to hand plank." },
          { name: "T-Push-ups", sets: 3, reps: "6 each side", instructions: "Push up, rotate to side plank, reach arm up." },
        ],
      },
    ],
  },
  {
    id: "built-different",
    emoji: "💪",
    title: "Built Different",
    subtitle: "Muscle hypertrophy & strength",
    level: "intermediate",
    daysPerWeek: 4,
    weeks: 8,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Chest & Triceps",
        exercises: [
          { name: "Wide Push-ups", sets: 4, reps: "15", instructions: "Hands wider than shoulders, full range." },
          { name: "Decline Push-ups", sets: 3, reps: "12", instructions: "Feet elevated on chair, works upper chest." },
          { name: "Tricep Dips", sets: 4, reps: "12", instructions: "Use chair, lower until elbows 90 degrees." },
          { name: "Close Grip Push-ups", sets: 3, reps: "10", instructions: "Hands shoulder-width, elbows close to body." },
        ],
      },
      {
        day: 2,
        name: "Back & Biceps",
        exercises: [
          { name: "Superman Hold", sets: 4, reps: "15 sec", duration: 15, instructions: "Lift arms and legs off floor, hold." },
          { name: "Reverse Snow Angels", sets: 3, reps: "12", instructions: "Face down, sweep arms overhead and back." },
          { name: "Towel Rows", sets: 4, reps: "12", instructions: "Door frame row using towel." },
          { name: "Bicep Curl (bottles)", sets: 3, reps: "15 each", instructions: "Use water bottles, curl to shoulder." },
        ],
      },
    ],
  },
  {
    id: "strength-muscle",
    emoji: "⚡",
    title: "Strength & Muscle",
    subtitle: "Progressive overload basics",
    level: "advanced",
    daysPerWeek: 5,
    weeks: 10,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Push Day",
        exercises: [
          { name: "Push-ups 3x20", sets: 3, reps: "20", instructions: "Perfect form, no cheating." },
          { name: "Incline Push-ups", sets: 4, reps: "15", instructions: "Hands elevated, works lower chest." },
          { name: "Pike Push-ups", sets: 4, reps: "12", instructions: "Inverted V, upper chest and shoulders." },
          { name: "Tricep Dips", sets: 4, reps: "15", instructions: "Full range of motion." },
        ],
      },
    ],
  },
  {
    id: "fat-loss",
    emoji: "💧",
    title: "Fat Loss Protocol",
    subtitle: "Science-based fat burning",
    level: "intermediate",
    daysPerWeek: 4,
    weeks: 8,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Metabolic Circuit",
        exercises: [
          { name: "Squat to Press", sets: 4, reps: "15", instructions: "Squat down, stand and press arms overhead." },
          { name: "Burpee to Tuck Jump", sets: 3, reps: "8", instructions: "Add tuck jump at the top of burpee." },
          { name: "Reverse Lunges", sets: 3, reps: "12 each", instructions: "Step back into lunge, return to stand." },
          { name: "Plank Jacks", sets: 3, reps: "20 sec", duration: 20, instructions: "Plank position, jump feet out and in." },
        ],
      },
    ],
  },
  {
    id: "home-workout",
    emoji: "🏠",
    title: "Home Warrior",
    subtitle: "No equipment needed",
    level: "beginner",
    daysPerWeek: 3,
    weeks: 6,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Total Body Home",
        exercises: [
          { name: "Bodyweight Squats", sets: 3, reps: "20", instructions: "Deep squat, keep chest up." },
          { name: "Push-ups", sets: 3, reps: "15", instructions: "Full range, controlled pace." },
          { name: "Jumping Jacks", sets: 3, reps: "30 sec", duration: 30, instructions: "Full range of motion." },
          { name: "Plank", sets: 3, reps: "30 sec", duration: 30, instructions: "Tight core, straight body." },
        ],
      },
    ],
  },
  {
    id: "gym-workout",
    emoji: "🏋️",
    title: "Gym Beast",
    subtitle: "Machine & free weight program",
    level: "intermediate",
    daysPerWeek: 5,
    weeks: 8,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Chest Day",
        exercises: [
          { name: "Bench Press", sets: 4, reps: "8-10", instructions: "Controlled descent, explosive press." },
          { name: "Incline Dumbbell Press", sets: 4, reps: "10", instructions: "30-45 degree incline." },
          { name: "Cable Flyes", sets: 3, reps: "12", instructions: "Feel the stretch at bottom." },
          { name: "Push-ups to Failure", sets: 2, reps: "max", instructions: "End of workout finisher." },
        ],
      },
    ],
  },
  {
    id: "core-mobility",
    emoji: "🎯",
    title: "Core & Mobility",
    subtitle: "Strengthen your center",
    level: "beginner",
    daysPerWeek: 3,
    weeks: 4,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Core Foundation",
        exercises: [
          { name: "Dead Bug", sets: 3, reps: "10 each", instructions: "Keep lower back pressed down." },
          { name: "Bird Dog", sets: 3, reps: "10 each", instructions: "Extend opposite arm and leg." },
          { name: "Side Plank", sets: 3, reps: "20 sec each", duration: 20, instructions: "Stack feet or stagger for easier." },
          { name: "Hollow Body Hold", sets: 3, reps: "20 sec", duration: 20, instructions: "Press lower back into floor." },
        ],
      },
    ],
  },
  {
    id: "yoga-flow",
    emoji: "🧘",
    title: "Yoga Flow Program",
    subtitle: "Mindful movement & flexibility",
    level: "beginner",
    daysPerWeek: 4,
    weeks: 6,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Sun Salutations",
        exercises: [
          { name: "Mountain Pose", sets: 1, reps: "60 sec", duration: 60, instructions: "Stand tall, breathe deeply." },
          { name: "Forward Fold", sets: 1, reps: "30 sec", duration: 30, instructions: "Hinge at hips, reach toward floor." },
          { name: "Downward Dog", sets: 1, reps: "45 sec", duration: 45, instructions: "Hips high, heels reaching down." },
          { name: "Warrior I", sets: 1, reps: "30 sec each", duration: 30, instructions: "Front knee over ankle, arms up." },
        ],
      },
    ],
  },
  {
    id: "recovery-stretch",
    emoji: "🌿",
    title: "Recovery & Stretch",
    subtitle: "Active recovery & restoration",
    level: "beginner",
    daysPerWeek: 3,
    weeks: 4,
    ltkReward: 50,
    days: [
      {
        day: 1,
        name: "Full Body Recovery",
        exercises: [
          { name: "Hamstring Stretch", sets: 2, reps: "45 sec each", duration: 45, instructions: "Seated forward fold, reach for toes." },
          { name: "Hip Flexor Stretch", sets: 2, reps: "45 sec each", duration: 45, instructions: "Kneeling lunge, sink hips forward." },
          { name: "Chest Opener", sets: 2, reps: "30 sec", duration: 30, instructions: "Arms behind, squeeze shoulder blades." },
          { name: "Child's Pose", sets: 1, reps: "60 sec", duration: 60, instructions: "Arms extended, breathe into back." },
        ],
      },
    ],
  },
];

export interface YogaPose {
  name: string;
  duration: number;
  instructions: string;
  breathCue: string;
}

export interface YogaFlow {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  duration: number;
  level: "beginner" | "intermediate" | "advanced";
  ltkReward: number;
  poses: YogaPose[];
}

export const YOGA_FLOWS: YogaFlow[] = [
  {
    id: "beginner-yoga",
    emoji: "🌸",
    title: "Beginner Yoga",
    subtitle: "Gentle introduction to yoga",
    duration: 20,
    level: "beginner",
    ltkReward: 25,
    poses: [
      { name: "Mountain Pose", duration: 60, instructions: "Stand tall with feet together, arms at sides. Feel grounded.", breathCue: "Breathe deeply, 4 counts in, 4 counts out." },
      { name: "Child's Pose", duration: 60, instructions: "Kneel and stretch arms forward, forehead to mat.", breathCue: "Breathe into your back body." },
      { name: "Cat-Cow", duration: 45, instructions: "On all fours, alternate arching and rounding spine.", breathCue: "Inhale on cow, exhale on cat." },
      { name: "Downward Dog", duration: 45, instructions: "Form an inverted V, press palms down, heels toward floor.", breathCue: "5 deep breaths here." },
      { name: "Warrior I", duration: 45, instructions: "Front knee over ankle, back foot at 45°, arms reach up.", breathCue: "Feel strong and grounded." },
      { name: "Warrior II", duration: 45, instructions: "Arms extended out, front knee bent, gaze forward.", breathCue: "Breathe and hold steady." },
      { name: "Tree Pose", duration: 45, instructions: "Balance on one foot, other foot on inner thigh or calf.", breathCue: "Find a focal point to balance." },
      { name: "Corpse Pose", duration: 90, instructions: "Lie flat on back, arms at sides, completely relax.", breathCue: "Let go of all tension." },
    ],
  },
  {
    id: "morning-flow",
    emoji: "🌅",
    title: "Morning Flow",
    subtitle: "Energize your day",
    duration: 15,
    level: "beginner",
    ltkReward: 25,
    poses: [
      { name: "Wake Up Stretch", duration: 45, instructions: "Lying on back, stretch arms and legs long.", breathCue: "Yawn and breathe deeply." },
      { name: "Knees to Chest", duration: 45, instructions: "Hug knees to chest, rock gently.", breathCue: "Massage your lower back." },
      { name: "Seated Forward Fold", duration: 60, instructions: "Legs extended, fold over legs.", breathCue: "Exhale deeper into the stretch." },
      { name: "Downward Dog", duration: 45, instructions: "Walk feet toward hands, flow into down dog.", breathCue: "Pedal your feet, wake up hamstrings." },
      { name: "Sun Salutation A", duration: 120, instructions: "Flow through full sun salutation sequence.", breathCue: "Move with your breath." },
      { name: "Standing Forward Fold", duration: 60, instructions: "Feet hip-width, fold over, bend knees slightly.", breathCue: "Let your head hang heavy." },
    ],
  },
  {
    id: "stress-relief",
    emoji: "💆",
    title: "Stress Relief",
    subtitle: "Calm your nervous system",
    duration: 25,
    level: "beginner",
    ltkReward: 25,
    poses: [
      { name: "Legs Up the Wall", duration: 120, instructions: "Lie with legs vertical against wall.", breathCue: "Slow, deep belly breaths." },
      { name: "Supported Child's Pose", duration: 90, instructions: "Bolster under chest, arms forward.", breathCue: "Breathe into your belly." },
      { name: "Seated Meditation", duration: 120, instructions: "Comfortable seated position, close eyes.", breathCue: "Count your breaths 1-10, repeat." },
      { name: "Supine Twist", duration: 60, instructions: "Lying down, bring knees to chest and twist each side.", breathCue: "Exhale into the twist." },
      { name: "Butterfly Pose", duration: 90, instructions: "Soles of feet together, fold forward gently.", breathCue: "Breathe into inner thighs." },
    ],
  },
  {
    id: "flexibility-flow",
    emoji: "🤸",
    title: "Flexibility Flow",
    subtitle: "Increase range of motion",
    duration: 30,
    level: "intermediate",
    ltkReward: 25,
    poses: [
      { name: "Hip Circles", duration: 45, instructions: "Standing, hands on hips, circle hips wide.", breathCue: "Breathe freely and fluidly." },
      { name: "Pigeon Pose", duration: 90, instructions: "Front leg bent at 90°, back leg extended.", breathCue: "Breathe into tight hips." },
      { name: "King Pigeon", duration: 60, instructions: "Reach back to bind foot in pigeon.", breathCue: "Open chest and breathe." },
      { name: "Splits Prep", duration: 90, instructions: "Low lunge, slide front foot forward.", breathCue: "Patience and breath." },
      { name: "Reverse Warrior", duration: 45, instructions: "From warrior II, lean back, reach arm overhead.", breathCue: "Breathe into the side body." },
      { name: "Wide Leg Forward Fold", duration: 60, instructions: "Feet wide, fold forward with straight back.", breathCue: "Gravity does the work." },
    ],
  },
  {
    id: "recovery-yoga",
    emoji: "💎",
    title: "Recovery Yoga",
    subtitle: "Post-workout restoration",
    duration: 20,
    level: "beginner",
    ltkReward: 25,
    poses: [
      { name: "Quadricep Stretch", duration: 45, instructions: "Standing, pull foot to glute, balance.", breathCue: "Feel the front of thigh open." },
      { name: "Hamstring Stretch", duration: 60, instructions: "Seated, one leg extended, reach for foot.", breathCue: "Exhale to deepen stretch." },
      { name: "Figure Four", duration: 60, instructions: "Lying down, cross ankle over opposite knee.", breathCue: "Breathe into hip and glute." },
      { name: "Chest Opener", duration: 45, instructions: "Arms behind back, clasp hands, lift chest.", breathCue: "Breathe into chest and shoulders." },
      { name: "Spinal Twist", duration: 60, instructions: "Seated twist, hand on opposite knee.", breathCue: "Exhale to twist deeper." },
    ],
  },
  {
    id: "sleep-unwind",
    emoji: "🌙",
    title: "Sleep & Unwind",
    subtitle: "Prepare for deep sleep",
    duration: 20,
    level: "beginner",
    ltkReward: 25,
    poses: [
      { name: "Legs Up the Wall", duration: 180, instructions: "Restorative inversion, legs vertical.", breathCue: "Box breathing: 4 in, 4 hold, 4 out, 4 hold." },
      { name: "Supine Butterfly", duration: 90, instructions: "Soles together, arms out like wings.", breathCue: "Let hips melt toward floor." },
      { name: "Supine Twist", duration: 90, instructions: "Twist each side, releasing spine.", breathCue: "Exhale fully on each twist." },
      { name: "Corpse Pose", duration: 180, instructions: "Full relaxation, scan body for tension.", breathCue: "Slow, counting breaths 1-10." },
    ],
  },
];

export interface MealPlan {
  breakfast: string;
  lunch: string;
  dinner: string;
  snack: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}

export interface DietPlan {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  days: MealPlan[];
}

export const DIET_PLANS: DietPlan[] = [
  {
    id: "fat-loss",
    emoji: "🔥",
    title: "Fat Loss",
    subtitle: "Caloric deficit for lean body",
    calories: 1800,
    protein: 150,
    carbs: 150,
    fats: 60,
    days: [
      {
        breakfast: "Greek yogurt with berries and granola",
        lunch: "Grilled chicken salad with olive oil dressing",
        dinner: "Baked salmon with roasted vegetables",
        snack: "Apple with almond butter",
        calories: 1800,
        protein: 150,
        carbs: 150,
        fats: 60,
      },
    ],
  },
  {
    id: "lean-muscle",
    emoji: "💪",
    title: "Lean Muscle",
    subtitle: "Build muscle while staying lean",
    calories: 2400,
    protein: 200,
    carbs: 250,
    fats: 70,
    days: [
      {
        breakfast: "Eggs and oatmeal with banana",
        lunch: "Ground turkey rice bowl",
        dinner: "Steak with sweet potato and broccoli",
        snack: "Protein shake with milk",
        calories: 2400,
        protein: 200,
        carbs: 250,
        fats: 70,
      },
    ],
  },
  {
    id: "balanced",
    emoji: "⚖️",
    title: "Balanced",
    subtitle: "Sustainable everyday nutrition",
    calories: 2000,
    protein: 130,
    carbs: 220,
    fats: 70,
    days: [
      {
        breakfast: "Smoothie bowl with fruit and seeds",
        lunch: "Turkey wrap with veggies",
        dinner: "Chicken stir-fry with rice",
        snack: "Hummus and vegetables",
        calories: 2000,
        protein: 130,
        carbs: 220,
        fats: 70,
      },
    ],
  },
  {
    id: "high-protein",
    emoji: "🥩",
    title: "High Protein",
    subtitle: "Maximize muscle synthesis",
    calories: 2600,
    protein: 240,
    carbs: 200,
    fats: 80,
    days: [
      {
        breakfast: "4 egg white omelette with cottage cheese",
        lunch: "Grilled chicken breast with quinoa",
        dinner: "Lean beef with asparagus",
        snack: "Casein protein before bed",
        calories: 2600,
        protein: 240,
        carbs: 200,
        fats: 80,
      },
    ],
  },
  {
    id: "budget-meals",
    emoji: "💰",
    title: "Budget Meals",
    subtitle: "Eat healthy on a budget",
    calories: 2000,
    protein: 140,
    carbs: 240,
    fats: 60,
    days: [
      {
        breakfast: "Oatmeal with peanut butter and banana",
        lunch: "Tuna and rice with canned beans",
        dinner: "Eggs with potatoes and frozen veggies",
        snack: "Peanut butter toast",
        calories: 2000,
        protein: 140,
        carbs: 240,
        fats: 60,
      },
    ],
  },
  {
    id: "clean-eating",
    emoji: "🥗",
    title: "Clean Eating",
    subtitle: "Whole foods only",
    calories: 1900,
    protein: 130,
    carbs: 200,
    fats: 70,
    days: [
      {
        breakfast: "Avocado toast on whole grain with poached eggs",
        lunch: "Quinoa bowl with roasted chickpeas",
        dinner: "Wild salmon with sautéed spinach and brown rice",
        snack: "Mixed nuts and fruit",
        calories: 1900,
        protein: 130,
        carbs: 200,
        fats: 70,
      },
    ],
  },
];
