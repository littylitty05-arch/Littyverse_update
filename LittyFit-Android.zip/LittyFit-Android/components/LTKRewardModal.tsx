import React, { useEffect, useRef } from "react";
import {
  Modal,
  View,
  Text,
  StyleSheet,
  Animated,
  Pressable,
  Platform,
} from "react-native";
import AppIcon from "@/components/AppIcon";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";

interface LTKRewardModalProps {
  visible: boolean;
  ltkAmount: number;
  title?: string;
  message?: string;
  onClose: () => void;
}

export default function LTKRewardModal({
  visible,
  ltkAmount,
  title = "Reward Earned!",
  message = "Great work! Keep it up.",
  onClose,
}: LTKRewardModalProps) {
  const colors = useColors();
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;
  const countAnim = useRef(new Animated.Value(0)).current;
  const [displayedCount, setDisplayedCount] = React.useState(0);

  useEffect(() => {
    if (visible) {
      scaleAnim.setValue(0);
      glowAnim.setValue(0);
      countAnim.setValue(0);
      setDisplayedCount(0);

      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }

      Animated.sequence([
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 100,
          friction: 6,
          useNativeDriver: true,
        }),
        Animated.loop(
          Animated.sequence([
            Animated.timing(glowAnim, {
              toValue: 1,
              duration: 800,
              useNativeDriver: true,
            }),
            Animated.timing(glowAnim, {
              toValue: 0,
              duration: 800,
              useNativeDriver: true,
            }),
          ]),
          { iterations: 3 }
        ),
      ]).start();

      Animated.timing(countAnim, {
        toValue: ltkAmount,
        duration: 1200,
        useNativeDriver: false,
      }).start();

      countAnim.addListener(({ value }) => {
        setDisplayedCount(Math.round(value));
      });
    } else {
      countAnim.removeAllListeners();
    }
  }, [visible]);

  const glowOpacity = glowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.4, 1],
  });

  return (
    <Modal transparent visible={visible} animationType="fade">
      <View style={styles.overlay}>
        <Animated.View
          style={[
            styles.container,
            {
              backgroundColor: colors.card,
              borderColor: colors.amber,
              transform: [{ scale: scaleAnim }],
            },
          ]}
        >
          <Animated.View style={[styles.iconContainer, { opacity: glowOpacity }]}>
            <AppIcon name="star" size={40} color={colors.amber} />
          </Animated.View>

          <Text style={[styles.title, { color: colors.textPrimary }]}>
            {title}
          </Text>

          <View style={styles.ltkRow}>
            <Text style={[styles.plus, { color: colors.amber }]}>+</Text>
            <Text style={[styles.amount, { color: colors.amber }]}>
              {displayedCount}
            </Text>
            <Text style={[styles.unit, { color: colors.amberLight }]}> LTK</Text>
          </View>

          <Text style={[styles.message, { color: colors.textSecondary }]}>
            {message}
          </Text>

          <Pressable
            style={[styles.button, { backgroundColor: colors.purple }]}
            onPress={() => {
              if (Platform.OS !== "web") {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }
              onClose();
            }}
          >
            <Text style={[styles.buttonText, { color: colors.textPrimary }]}>
              Claim Reward
            </Text>
          </Pressable>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    alignItems: "center",
    justifyContent: "center",
  },
  container: {
    width: 300,
    borderRadius: 24,
    padding: 28,
    alignItems: "center",
    borderWidth: 2,
    shadowColor: "#f59e0b",
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 10,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "rgba(245,158,11,0.15)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 12,
    textAlign: "center",
  },
  ltkRow: {
    flexDirection: "row",
    alignItems: "baseline",
    marginBottom: 12,
  },
  plus: {
    fontSize: 32,
    fontWeight: "900",
  },
  amount: {
    fontSize: 56,
    fontWeight: "900",
  },
  unit: {
    fontSize: 24,
    fontWeight: "700",
  },
  message: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: 24,
  },
  button: {
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 14,
    width: "100%",
    alignItems: "center",
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "700",
  },
});
