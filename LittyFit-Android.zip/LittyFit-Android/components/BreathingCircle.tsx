import React, { useEffect, useRef, useState } from "react";
import { Animated, Text, View, StyleSheet, Pressable, Platform } from "react-native";
import * as Haptics from "expo-haptics";

const PHASES = [
  { label: "Inhale", duration: 4000, scale: 1.0 },
  { label: "Hold", duration: 7000, scale: 1.0 },
  { label: "Exhale", duration: 8000, scale: 0.0 },
  { label: "Hold", duration: 0, scale: 0.0 },
] as const;

interface BreathingCircleProps {
  size?: number;
  primaryColor?: string;
  onCycleComplete?: () => void;
}

export default function BreathingCircle({
  size = 180,
  primaryColor = "#38bdf8",
  onCycleComplete,
}: BreathingCircleProps) {
  const [running, setRunning] = useState(false);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [seconds, setSeconds] = useState(4);
  const scaleAnim = useRef(new Animated.Value(0.55)).current;
  const opacityAnim = useRef(new Animated.Value(0.3)).current;
  const cycleRef = useRef<any>(null);
  const timerRef = useRef<any>(null);

  const stop = () => {
    setRunning(false);
    setPhaseIdx(0);
    setSeconds(4);
    clearTimeout(cycleRef.current);
    clearInterval(timerRef.current);
    Animated.parallel([
      Animated.spring(scaleAnim, { toValue: 0.55, useNativeDriver: true }),
      Animated.timing(opacityAnim, { toValue: 0.3, duration: 400, useNativeDriver: true }),
    ]).start();
  };

  const runCycle = (idx: number) => {
    const phase = PHASES[idx];
    setPhaseIdx(idx);

    const target = idx === 0 || idx === 1 ? 0.9 : 0.55;
    const opTarget = idx === 0 || idx === 1 ? 0.8 : 0.25;
    const dur = phase.duration || 1000;

    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    clearInterval(timerRef.current);
    let count = Math.floor(dur / 1000);
    setSeconds(count);
    timerRef.current = setInterval(() => {
      count--;
      setSeconds(count);
      if (count <= 0) clearInterval(timerRef.current);
    }, 1000);

    Animated.parallel([
      Animated.timing(scaleAnim, { toValue: target, duration: dur, useNativeDriver: true }),
      Animated.timing(opacityAnim, { toValue: opTarget, duration: dur, useNativeDriver: true }),
    ]).start();

    const nextIdx = (idx + 1) % PHASES.length;
    const nextDur = PHASES[nextIdx].duration || 1000;
    cycleRef.current = setTimeout(() => {
      if (nextIdx === 0) onCycleComplete?.();
      runCycle(nextIdx);
    }, dur);
  };

  const start = () => {
    setRunning(true);
    runCycle(0);
  };

  useEffect(() => () => { clearTimeout(cycleRef.current); clearInterval(timerRef.current); }, []);

  const phase = PHASES[phaseIdx];

  return (
    <View style={styles.container}>
      <View style={[styles.outerRing, { width: size + 40, height: size + 40, borderRadius: (size + 40) / 2, borderColor: `${primaryColor}20` }]}>
        <Animated.View
          style={[
            styles.pulseRing,
            {
              width: size + 20,
              height: size + 20,
              borderRadius: (size + 20) / 2,
              backgroundColor: `${primaryColor}15`,
              opacity: opacityAnim,
              transform: [{ scale: scaleAnim }],
            },
          ]}
        />
        <Pressable
          onPress={running ? stop : start}
          style={[styles.circle, { width: size, height: size, borderRadius: size / 2, borderColor: primaryColor + "60", backgroundColor: `${primaryColor}12` }]}
        >
          <Text style={[styles.phaseLabel, { color: primaryColor }]}>
            {running ? phase.label : "Start"}
          </Text>
          {running && (
            <Text style={[styles.phaseCount, { color: primaryColor }]}>{seconds}s</Text>
          )}
          {!running && (
            <Text style={[styles.tapHint, { color: primaryColor + "80" }]}>4-7-8 breathing</Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", justifyContent: "center" },
  outerRing: { alignItems: "center", justifyContent: "center", borderWidth: 1 },
  pulseRing: { position: "absolute" },
  circle: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    gap: 4,
  },
  phaseLabel: { fontSize: 22, fontWeight: "800" },
  phaseCount: { fontSize: 36, fontWeight: "900" },
  tapHint: { fontSize: 12, textAlign: "center" },
});
