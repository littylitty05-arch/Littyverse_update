import * as SecureStore from "expo-secure-store";

const API_BASE = process.env.EXPO_PUBLIC_API_URL ?? "";

export async function apiFetch(
  path: string,
  options?: RequestInit
): Promise<Response> {
  let token: string | null = null;
  try {
    token = await SecureStore.getItemAsync("ltk_token");
  } catch {}

  return fetch(API_BASE + path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
      ...(options?.headers ?? {}),
    },
  });
}
